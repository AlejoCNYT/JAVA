import presentacion.GOMOKUGUI;

public class main {
    public static void main(String[] args) {
        GOMOKUGUI inicio = new GOMOKUGUI();
        inicio.setVisible(true);
    }
}
