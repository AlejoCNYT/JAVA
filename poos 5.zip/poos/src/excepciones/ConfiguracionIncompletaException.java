package excepciones;

public class ConfiguracionIncompletaException extends Exception {
    public static final String ERROR_MESSAGE = "La configuración está incompleta";
    public static final String no_found_token = "Error al disminuir fichas";
    public static final String pocision_ocupada = "No se puede asignar una ficha en una posición ocupada.";

    public ConfiguracionIncompletaException(String mensaje) {
        super(mensaje);
    }
}
