package excepciones;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Log {
    private static final Logger logger = Logger.getLogger(Log.class.getName());

    public static void configurarLog() {
        try {
            FileHandler fileHandler = new FileHandler("errores.log", true);
            fileHandler.setFormatter(new SimpleFormatter());
            logger.addHandler(fileHandler);
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Error al configurar el archivo de log", e);
        }
    }

    public static void registrarError(String mensaje, Throwable throwable) {
        logger.log(Level.SEVERE, mensaje, throwable);
    }
}
