package Domain;

import Domain.elementos.casillas.Casilla;
import Domain.elementos.casillas.Golden;
import Domain.elementos.casillas.Mine;
import Domain.elementos.casillas.Teleport;
import Domain.elementos.elemento;
import Domain.elementos.fichas.Token;
import Domain.elementos.fichas.temporal;
import controller.GomokuController;
import presentacion.configuraciones.settings;
import presentacion.juego.GomokuJuego;
import java.io.Serializable;
import java.awt.*;
import presentacion.configuraciones.settings;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import javax.swing.JOptionPane;
import java.io.IOException;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class DomainGomoku extends Component implements Serializable {
    protected GomokuController control;
    protected elemento[][] posiciones;
    private String ganadorColor;
    private  long serialVersionUID = 1L;;

    private Map<String, Integer> numeroTokenBlanco, numeroTokenNegro;
    private int numeroPesada, numeroTemporal, numeroNormal;
    protected int turno;

    public DomainGomoku(GomokuController control) {
        this.control = control;
        turno=1;
    }
    public elemento[][] generateCasillas(int tamañoTablero){
        posiciones = new elemento[tamañoTablero][tamañoTablero];
        int numeroDeMine = new Random().nextInt(1,posiciones.length-1);
        int numeroDeTeleport = new Random().nextInt(1,posiciones.length-1);
        int numeroDeGold = new Random().nextInt(1,posiciones.length-1);
        PreparedMine(numeroDeMine);
        PreparedTeleport(numeroDeTeleport);
        PreparedGolden(numeroDeGold);
        return posiciones;
    }
    public void PreparedMine(int numeroDeMine){
        for (int i = 0; i < numeroDeMine;i++){
            int fila = new Random().nextInt(posiciones.length-1);
            int columna = new Random().nextInt(posiciones.length-1);
            posiciones[fila][columna] = new Mine(fila,columna);
        }
    }

    public void PreparedTeleport(int numeroDeTeleport){
        for (int i = 0; i < numeroDeTeleport;i++){
            int fila = new Random().nextInt(posiciones.length-1);
            int columna = new Random().nextInt(posiciones.length-1);
            posiciones[fila][columna] = new Teleport(fila,columna);
        }
    }
    public void PreparedGolden(int PreparedGolden){
        for (int i = 0; i < PreparedGolden;i++){
            int fila = new Random().nextInt(posiciones.length-1);
            int columna = new Random().nextInt(posiciones.length-1);
            posiciones[fila][columna] = new Golden(fila,columna);
        }
    }

    public elemento[][] getPosiciones() {
        return posiciones;
    }

    public void actualizarMatriz(elemento[][] posiciones,int turno) {
        this.turno = turno;
        this.posiciones = posiciones;
        verificador();
        temporal();
    }

    public void temporal() {
        for (elemento[] tokens : posiciones) {
            for (elemento token : tokens) {
                if (token instanceof temporal) {
                    temporal temporal = (temporal) token;
                    if (temporal.getVida() > 0) {
                        temporal.sumaOne();
                    } else {
                        posiciones[temporal.getI()][temporal.getJ()] = null;
                    }
                }
            }
        }
    }

    public Map<String, Integer> generateTokensBlancas(int fichasEspeciales) {
        numeroTokenBlanco = new HashMap<>();
        double porcentaje = (fichasEspeciales / 100.0) * (posiciones.length * posiciones.length);

        numeroTemporal = new Random().nextInt((int) porcentaje);
        numeroPesada = (int) (porcentaje - numeroTemporal);
        numeroNormal = (posiciones.length * posiciones.length) - numeroTemporal - numeroPesada;

        numeroTokenBlanco.put("normal", numeroNormal);
        numeroTokenBlanco.put("temporal", numeroTemporal);
        numeroTokenBlanco.put("pesada", numeroPesada);
        return numeroTokenBlanco;
    }

    public Map<String, Integer> generateTokensNegras(int fichasEspeciales) {
        numeroTokenNegro = new HashMap<>();
        double porcentaje = (fichasEspeciales / 100.0) * (posiciones.length * posiciones.length);

        numeroTemporal = new Random().nextInt((int) porcentaje);
        numeroPesada = (int) (porcentaje - numeroTemporal);
        numeroNormal = (posiciones.length * posiciones.length) - numeroTemporal - numeroPesada;

        numeroTokenNegro.put("normal", numeroNormal);
        numeroTokenNegro.put("temporal", numeroTemporal);
        numeroTokenNegro.put("pesada", numeroPesada);

        return numeroTokenNegro;
    }



    public elemento[][] verificarCasilla(int i, int j,Token ficha){
        if(posiciones[i][j] instanceof Golden){
            control.mensajeGolden();
            control.poner(i,j);
        }
        if(posiciones[i][j] instanceof Casilla){
            if(posiciones[i][j] instanceof Mine){
                control.cambiarPuntaje(((Mine) posiciones[i][j]).calcularPuntaje(posiciones,turno));
            }
            posiciones=posiciones[i][j].actuar(posiciones,ficha);
        }
        else{
            control.poner(i,j);
        }
        return posiciones;
    }



    public int generateNumeroDeFichasLimitadas() {
        numeroNormal = new Random().nextInt(100);
        return numeroNormal;
    }

    public void imprimirHash(Map<String, Integer> tokens) {
        for (Map.Entry<String, Integer> entry : tokens.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

    public String getGanadorColor() {
        return ganadorColor;
    }

    public boolean verificador() {
        return cincoEnLinea();
    }

    public boolean cincoEnLinea() {
        return lineaHorizontal() || lineaVertical() || lineaDiagonalPrincipal() || lineaDiagonalSecundaria();
    }

    private boolean lineaHorizontal() {
        for (int i = 0; i < posiciones.length; i++) {
            for (int j = 0; j < posiciones[i].length - 4; j++) {
                if (posiciones[i][j] instanceof Token && posiciones[i][j].getColor() != null) {
                    Token jugador = (Token) posiciones[i][j];
                    int cont = jugador.getValor();

                    for (int k = 1; k < 5; k++) {
                        if (posiciones[i][j + k] == null || !jugador.getColor().equals(posiciones[i][j + k].getColor())) {
                            break;
                        } else {
                            cont += posiciones[i][j + k].getValor();
                        }
                    }
                    if (cont == 5) {
                        ganadorColor = jugador.getColor();
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean lineaVertical() {
        for (int j = 0; j < posiciones[0].length; j++) {
            for (int i = 0; i < posiciones.length - 4; i++) {
                if (posiciones[i][j] != null && posiciones[i][j].getColor() != null) {
                    Token jugador = (Token) posiciones[i][j];
                    int cont = jugador.getValor();

                    for (int k = 1; k < 5; k++) {
                        if (posiciones[i + k][j] == null || !jugador.getColor().equals(posiciones[i + k][j].getColor())) {
                            break;
                        } else {
                            cont += posiciones[i + k][j].getValor();
                        }
                    }

                    if (cont == 5) {
                        ganadorColor = jugador.getColor();
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean lineaDiagonalPrincipal() {
        for (int i = 0; i < posiciones.length - 4; i++) {
            for (int j = 0; j < posiciones[i].length - 4; j++) {
                if (posiciones[i][j] != null && posiciones[i][j].getColor() != null) {
                    Token jugador = (Token) posiciones[i][j];
                    int cont = jugador.getValor();

                    for (int k = 1; k < 5; k++) {
                        if (posiciones[i + k][j + k] == null || !jugador.getColor().equals(posiciones[i + k][j + k].getColor())) {
                            break;
                        } else {
                            cont += posiciones[i + k][j + k].getValor();
                        }
                    }

                    if (cont == 5) {
                        ganadorColor = jugador.getColor();
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean lineaDiagonalSecundaria() {
        for (int i = 4; i < posiciones.length; i++) {
            for (int j = 0; j < posiciones[i].length - 4; j++) {
                if (posiciones[i][j] != null && posiciones[i][j].getColor() != null) {
                    Token jugador = (Token) posiciones[i][j];
                    int cont = jugador.getValor();

                    for (int k = 1; k < 5; k++) {
                        if (posiciones[i - k][j + k] == null || !jugador.getColor().equals(posiciones[i - k][j + k].getColor())) {
                            break;
                        } else {
                            cont += posiciones[i - k][j + k].getValor();
                        }
                    }

                    if (cont == 5) {
                        ganadorColor = jugador.getColor();
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public void guardar(GomokuJuego estado) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Guardar Archivo");
        fileChooser.setFileFilter(new FileNameExtensionFilter("Archivos de datos (*.dat)", "dat"));
        int seleccion = fileChooser.showSaveDialog(this);
        if (seleccion == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(archivo))) {
                Contenedor contenedor = new Contenedor(estado, this);
                salida.writeObject(contenedor);
                JOptionPane.showMessageDialog(null, "Datos guardados correctamente");
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error al guardar los datos");
            }
        }
    }
    public GomokuJuego cargar() {
        GomokuJuego estado = null;
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();

            try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(selectedFile))) {
                Contenedor contenedor = (Contenedor) entrada.readObject();
                this.control = contenedor.getDomainGomoku().control;
                this.posiciones = contenedor.getDomainGomoku().posiciones;
                this.ganadorColor = contenedor.getDomainGomoku().ganadorColor;
                settings.juegoCargado(contenedor.getGomokuJuego());
                control.cambioDeJuego(contenedor.getGomokuJuego());
                JOptionPane.showMessageDialog(null, "Datos cargados correctamente");
            } catch (IOException | ClassNotFoundException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error al cargar los datos");
            }
        }
        return estado;
    }



    public void enviarMatriz() {
        control.enviarMatriz(posiciones);
    }


}
