package Domain.cpuMentalidad;

import Domain.DomainGomokuCpu;
import Domain.elementos.elemento;
import Domain.elementos.fichas.Token;

public class cpuConTodasLasFichas implements CPU{
    private DomainGomokuCpu domainGomokuCpu;
    private String mentalidad;
    public cpuConTodasLasFichas(DomainGomokuCpu domainGomokuCpu,String mentalidad) {
        this.domainGomokuCpu= domainGomokuCpu;
        this.mentalidad = mentalidad;
    }

    @Override
    public void actuar(elemento[][] posiciones) {
        Token normal = new Token(0,0,"negro");
        domainGomokuCpu.ponerFicha(0,0,normal);
    }
}
