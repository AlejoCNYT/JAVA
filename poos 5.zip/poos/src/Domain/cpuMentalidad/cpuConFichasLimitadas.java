package Domain.cpuMentalidad;

import Domain.DomainGomokuCpu;
import Domain.elementos.elemento;
import Domain.elementos.fichas.Token;
import java.util.ArrayList;
import Domain.elementos.elemento;
import Domain.elementos.fichas.Token;
import java.util.ArrayList;
import java.util.Random;

public class cpuConFichasLimitadas implements CPU {
    private DomainGomokuCpu domainGomokuCpu;
    private String mentalidad;
    private ArrayList<elemento> posicionesAtaque;
    private boolean empezo;

    public cpuConFichasLimitadas(DomainGomokuCpu domainGomokuCpu, String mentalidad) {
        this.domainGomokuCpu = domainGomokuCpu;
        this.mentalidad = mentalidad;
        empezo = false;
        this.posicionesAtaque = new ArrayList<>();
    }

    @Override
    public void actuar(elemento[][] posiciones) {
        switch (mentalidad) {
            case "Agresiva":
                actuarAgresiva(posiciones);
                break;
            case "Experta":
                actuarExperta(posiciones);
                break;
            case "Miedosa":
                actuarMiedosa(posiciones);
                break;
            case "Master":
                actuarMaster(posiciones);
        }
    }


    /////////////////////////////-> mentalidad miedosa<-///////////////////////////////////////////////////
    public void actuarMiedosa(elemento[][] posiciones) {
        int[] posicionContrario = encontrarPosicionContrario(posiciones);

        int[] posicionOpuesta = encontrarPosicionOpuesta(posicionContrario, posiciones);

        Token ficha = new Token(posicionOpuesta[0], posicionOpuesta[1], "negro");
        domainGomokuCpu.ponerFicha(posicionOpuesta[0], posicionOpuesta[1], ficha);
    }

    private int[] encontrarPosicionContrario(elemento[][] posiciones) {
        for (int i = 0; i < posiciones.length; i++) {
            for (int j = 0; j < posiciones[0].length; j++) {
                if (posiciones[i][j] != null && posiciones[i][j].getColor().equals("blanco")) {
                    return new int[]{i, j};
                }
            }
        }
        return null;
    }

    private int[] encontrarPosicionOpuesta(int[] posicionContrario, elemento[][] posiciones) {
        int filaOpuesta = posiciones.length - 1 - posicionContrario[0];
        int columnaOpuesta = posiciones[0].length - 1 - posicionContrario[1];

        if (filaOpuesta >= 0 && filaOpuesta < posiciones.length &&
                columnaOpuesta >= 0 && columnaOpuesta < posiciones[0].length &&
                posiciones[filaOpuesta][columnaOpuesta] == null) {
            return new int[]{filaOpuesta, columnaOpuesta};
        } else {
            return new int[]{(int) (Math.random() * posiciones.length), (int) (Math.random() * posiciones[0].length)};
        }
    }

    /////////////////////////////-> mentalidad agresiva<-///////////////////////////////////////////////////

    public void actuarAgresiva(elemento[][] posiciones) {
        int[] posicion = buscarJugadaAgresiva(posiciones);

        if (posicion != null) {
            Token ficha = new Token(posicion[0], posicion[1], "negro");
            domainGomokuCpu.ponerFicha(posicion[0], posicion[1], ficha);
        } else {
            // Si no hay jugada agresiva posible, actuar aleatoriamente
            actuarAleatoria(posiciones);
        }
    }

    private int[] buscarJugadaAgresiva(elemento[][] posiciones) {
        for (int i = 0; i < posiciones.length; i++) {
            for (int j = 0; j < posiciones[i].length; j++) {
                if (esMovimientoValido(posiciones, i, j)) {
                    posiciones[i][j] = new Token(i, j, "negro");

                    if (conectarCinco(posiciones, i, j)) {
                        posiciones[i][j] = null;
                        return new int[]{i, j};
                    }

                    posiciones[i][j] = null;
                }
            }
        }

        return null;
    }

    private boolean conectarCinco(elemento[][] posiciones, int fila, int columna) {
        // Verificar si la ficha en la posición dada conecta 5 fichas en alguna dirección

        return (contarFichasEnDireccion(posiciones, fila, columna, 1, 0) +
                contarFichasEnDireccion(posiciones, fila, columna, 0, 1) +
                contarFichasEnDireccion(posiciones, fila, columna, 1, 1) +
                contarFichasEnDireccion(posiciones, fila, columna, 1, -1)) >= 4;
    }

    private int contarFichasEnDireccion(elemento[][] posiciones, int fila, int columna, int deltaFila, int deltaColumna) {
        // Contar el número de fichas del mismo color en una dirección
        int contador = 0;
        String color = posiciones[fila][columna].getColor();

        while (fila >= 0 && fila < posiciones.length && columna >= 0 && columna < posiciones[0].length &&
                posiciones[fila][columna] != null && posiciones[fila][columna].getColor().equals(color)) {
            contador++;
            fila += deltaFila;
            columna += deltaColumna;
        }

        return contador;
    }

    private void actuarAleatoria(elemento[][] posiciones) {
        Random random = new Random();
        int fila, columna;
        do {
            fila = random.nextInt(posiciones.length);
            columna = random.nextInt(posiciones[0].length);
        } while (posiciones[fila][columna] != null);
        Token ficha = new Token(fila, columna, "negro");
        domainGomokuCpu.ponerFicha(fila, columna, ficha);
    }

    /////////////////////////////-> mentalidad experta<-///////////////////////////////////////////////////

    public void actuarExperta(elemento[][] posiciones) {
        int[] posicion = calcularPosicion(posiciones);
        if (posicion != null){
            Token ficha = new Token(posicion[0], posicion[1], "negro");
            domainGomokuCpu.ponerFicha(posicion[0], posicion[1], ficha);
        }
        else {
            actuarAleatoria(posiciones);
        }
    }

    public int[] calcularPosicion(elemento[][] posiciones) {
        int[] posicion;
        posicion = verificarHorizontal(posiciones);
        if (posicion != null) {
            return posicion;
        }
        posicion = verificarVertical(posiciones);
        if (posicion != null) {
            return posicion;
        }
        posicion = verificarDiagonalIzquierdaDerecha(posiciones);
        if (posicion != null) {
            return verificarDiagonalIzquierdaDerecha(posiciones);
        }
        posicion = verificarDiagonalDerechaIzquierda(posiciones);
        if (posicion != null) {
            return verificarDiagonalDerechaIzquierda(posiciones);
        }

        return null;
    }
    public int[] verificarHorizontal(elemento[][] posiciones) {
        for (int i = 0; i < posiciones.length; i++) {
            for (int j = 0; j <= posiciones[i].length - 4; j++) {
                int cont3 = 0;
                int cont4 = 0;

                for (int k = 0; k < 4; k++) {
                    if (posiciones[i][j + k] != null && posiciones[i][j + k].getColor().equals("blanco")) {
                        cont3++;
                        cont4++;
                    }
                }

                if ((cont3 == 3 && j + 3 < posiciones[i].length && posiciones[i][j + 3] == null) ||
                        (cont4 == 3 && j + 3 < posiciones[i].length && posiciones[i][j + 3] == null) ||
                        (cont4 == 4 && j + 4 < posiciones[i].length && posiciones[i][j + 4] == null)) {

                    return new int[]{i, cont4 == 4 ? j + 4 : j + 3};
                } else if (cont3 == 3 && j + 3 < posiciones[i].length && posiciones[i][j + 3] != null &&
                        cont4 == 3 && j - 1 >= 0 && posiciones[i][j] == null) {
                    return new int[]{i, j};
                }
            }
        }

        return null;
    }

    public int[] verificarVertical(elemento[][] posiciones) {
        for (int i = 0; i <= posiciones.length - 4; i++) {
            for (int j = 0; j < posiciones[i].length; j++) {
                int cont3 = 0;
                int cont4 = 0;
                for (int k = 0; k < 4; k++) {
                    if (posiciones[i + k][j] != null && posiciones[i + k][j].getColor().equals("blanco")) {
                        cont3++;
                        cont4++;
                    }
                }
                if ((cont3 == 3 && i + 3 < posiciones.length && posiciones[i + 3][j] == null) ||
                        (cont4 == 3 && i + 3 < posiciones.length && posiciones[i + 3][j] == null) ||
                        (cont4 == 4 && i + 4 < posiciones.length && posiciones[i + 4][j] == null)) {
                    return new int[]{cont4 == 4 ? i + 4 : i + 3, j};
                } else if (cont3 == 3 && i + 3 < posiciones.length && posiciones[i + 3][j] != null &&
                        cont4 == 3 && posiciones[i][j] == null) {
                    return new int[]{i, j};
                }
            }
        }

        return null;
    }


    public int[] verificarDiagonalIzquierdaDerecha(elemento[][] posiciones) {
        for (int i = 0; i <= posiciones.length - 4; i++) {
            for (int j = 0; j <= posiciones[i].length - 4; j++) {
                int cont3 = 0;
                int cont4 = 0;

                for (int k = 0; k < 4; k++) {
                    if (posiciones[i + k][j + k] != null && posiciones[i + k][j + k].getColor().equals("blanco")) {
                        cont3++;
                        cont4++;
                    }
                }

                if ((cont3 == 3 && i + 3 < posiciones.length && j + 3 < posiciones[i].length && posiciones[i + 3][j + 3] == null) ||
                        (cont4 == 4 && i + 4 < posiciones.length && j + 4 < posiciones[i].length && posiciones[i + 4][j + 4] == null)) {
                    return new int[]{i + (cont4 == 4 ? 4 : 3), j + (cont4 == 4 ? 4 : 3)};
                } else if (cont3 == 3 && i + 3 < posiciones.length && j + 3 < posiciones[i].length && posiciones[i + 3][j + 3] != null &&
                        cont4 == 3 && posiciones[i][j] == null) {
                    return new int[]{i, j};
                }
            }
        }

        return null;
    }


    public int[] verificarDiagonalDerechaIzquierda(elemento[][] posiciones) {
        for (int i = 0; i <= posiciones.length - 4; i++) {
            for (int j = 3; j < posiciones[i].length - 3; j++) {
                int cont3 = 0;
                int cont4 = 0;

                for (int k = 0; k < 4; k++) {
                    if (posiciones[i + k][j - k] != null && posiciones[i + k][j - k].getColor().equals("blanco")) {
                        cont3++;
                        cont4++;
                    }
                }

                if ((cont3 == 3 && i + 3 < posiciones.length && j - 3 >= 0 && posiciones[i + 3][j - 3] == null) ||
                        (cont4 == 4 && i + 4 < posiciones.length && j - 4 >= 0 && posiciones[i + 4][j - 4] == null)) {
                    return new int[]{i + (cont4 == 4 ? 4 : 3), j - (cont4 == 4 ? 4 : 3)};
                } else if (cont3 == 3 && i + 3 < posiciones.length && j - 3 >= 0 && posiciones[i + 3][j - 3] != null &&
                        cont4 == 3 && posiciones[i][j] == null) {
                    return new int[]{i, j};
                }
            }
        }

        return null;
    }

    /////////////////////////////-> mentalidad master<-///////////////////////////////////////////////////

    public void actuarMaster(elemento[][] posiciones) {
        int profundidadMaxima = 3;  // Ajusta la profundidad según tus necesidades
        int[] mejorJugada = minimaxConPoda(posiciones, "negro", profundidadMaxima, Integer.MIN_VALUE, Integer.MAX_VALUE, true);

        Token ficha = new Token(mejorJugada[1], mejorJugada[2], "negro");
        domainGomokuCpu.ponerFicha(mejorJugada[1], mejorJugada[2], ficha);
    }

    private int[] minimaxConPoda(elemento[][] posiciones, String color, int profundidad, int alfa, int beta, boolean maximizando) {
        if (profundidad == 0 || juegoTerminado(posiciones)) {
            int evaluacion = evaluarPosicion(posiciones, color);
            return new int[]{evaluacion, -1, -1};
        }

        int[] mejorJugada = new int[]{maximizando ? Integer.MIN_VALUE : Integer.MAX_VALUE, -1, -1};

        for (int i = 0; i < posiciones.length; i++) {
            for (int j = 0; j < posiciones[i].length; j++) {
                if (esMovimientoValido(posiciones, i, j)) {
                    posiciones[i][j] = new Token(i, j, color);

                    int[] resultado;
                    if (maximizando) {
                        resultado = minimaxConPoda(posiciones, "blanco", profundidad - 1, alfa, beta, false);
                        alfa = Math.max(alfa, resultado[0]);
                    } else {
                        resultado = minimaxConPoda(posiciones, "negro", profundidad - 1, alfa, beta, true);
                        beta = Math.min(beta, resultado[0]);
                    }

                    posiciones[i][j] = null;

                    if ((maximizando && resultado[0] > mejorJugada[0]) || (!maximizando && resultado[0] < mejorJugada[0])) {
                        mejorJugada[0] = resultado[0];
                        mejorJugada[1] = i;
                        mejorJugada[2] = j;
                    }

                    if (alfa >= beta) {
                        break;
                    }
                }
            }
        }

        return mejorJugada;
    }


    private int evaluarPosicion(elemento[][] posiciones, String color) {
        int puntajeTotal = 0;

        // Evaluar en todas las direcciones
        for (int deltaFila = -1; deltaFila <= 1; deltaFila++) {
            for (int deltaColumna = -1; deltaColumna <= 1; deltaColumna++) {
                if (deltaFila != 0 || deltaColumna != 0) {
                    int puntaje = evaluarConsecutivos(posiciones, color, 5, deltaFila, deltaColumna);
                    puntajeTotal += puntaje;
                }
            }
        }

        // Considerar las esquinas como jugadas estratégicas
        if (puntajeTotal < 10) {
            int[][] esquinas = {{0, 0}, {0, posiciones[0].length - 1}, {posiciones.length - 1, 0}, {posiciones.length - 1, posiciones[0].length - 1}};
            for (int[] esquina : esquinas) {
                int fila = esquina[0];
                int columna = esquina[1];
                if (esMovimientoValido(posiciones, fila, columna)) {
                    puntajeTotal += 50; // Puntaje alto para motivar la elección de esquinas
                }
            }
        }

        return puntajeTotal;
    }


    private boolean esMovimientoValido(elemento[][] posiciones, int fila, int columna) {
        return posiciones[fila][columna] == null;
    }
    private boolean juegoTerminado(elemento[][] posiciones) {
        return hayGanadorEnFilas(posiciones) || hayGanadorEnColumnas(posiciones) || hayGanadorEnDiagonales(posiciones);
    }

    private boolean hayGanadorEnFilas(elemento[][] posiciones) {
        for (int i = 0; i < posiciones.length; i++) {
            for (int j = 0; j <= posiciones[i].length - 5; j++) {
                if (hayConsecutivos(posiciones, i, j, 5)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean hayGanadorEnColumnas(elemento[][] posiciones) {
        for (int i = 0; i <= posiciones.length - 5; i++) {
            for (int j = 0; j < posiciones[i].length; j++) {
                if (hayConsecutivos(posiciones, i, j, 5)) {
                    return true;
                }
            }
        }
        return false;
    }


    private boolean hayGanadorEnDiagonales(elemento[][] posiciones) {
        for (int i = 0; i <= posiciones.length - 5; i++) {
            for (int j = 0; j <= posiciones[i].length - 5; j++) {
                if (hayConsecutivosDiagonalDerechaIzquierda(posiciones, i, j, 5) ||
                        hayConsecutivosDiagonalIzquierdaDerecha(posiciones, i, j, 5)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean hayConsecutivos(elemento[][] posiciones, int fila, int columna, int cantidad) {
        int filas = posiciones.length;
        int columnas = posiciones[0].length;

        if (columna < 0 || columna >= columnas) {
            return false;
        }

        for (int k = 0; k < cantidad; k++) {
            if (fila >= 0 && fila < filas && columna + k >= 0 && columna + k < columnas) {
                if (posiciones[fila][columna + k] == null || !posiciones[fila][columna + k].getColor().equals("negro")) {
                    return false;
                }
            } else {
                return false;
            }
        }
        return true;
    }


    private boolean hayConsecutivosDiagonalDerechaIzquierda(elemento[][] posiciones, int fila, int columna, int cantidad) {
        for (int k = 0; k < cantidad; k++) {
            if (posiciones[fila + k][columna + k] == null || !posiciones[fila + k][columna + k].getColor().equals("negro")) {
                return false;
            }
        }
        return true;
    }

    private boolean hayConsecutivosDiagonalIzquierdaDerecha(elemento[][] posiciones, int fila, int columna, int cantidad) {
        for (int k = 0; k < cantidad; k++) {
            if (fila + k >= 0 && fila + k < posiciones.length &&
                    columna - k >= 0 && columna - k < posiciones[0].length) {

                if (posiciones[fila + k][columna - k] == null ||
                        !posiciones[fila + k][columna - k].getColor().equals("negro")) {
                    return false;
                }
            } else {
                return false;
            }
        }
        return true;
    }


    private int evaluarConsecutivos(elemento[][] posiciones, String color, int longitud, int deltaFila, int deltaColumna) {
        int puntaje = 0;
        int filas = posiciones.length;
        int columnas = posiciones[0].length;

        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                int consecutivosCPU = 0;
                int consecutivosOponente = 0;

                for (int k = 0; k < longitud; k++) {
                    int nuevaFila = i + k * deltaFila;
                    int nuevaColumna = j + k * deltaColumna;

                    if (nuevaFila >= 0 && nuevaFila < filas && nuevaColumna >= 0 && nuevaColumna < columnas) {
                        if (posiciones[nuevaFila][nuevaColumna] != null) {
                            String colorActual = posiciones[nuevaFila][nuevaColumna].getColor();

                            if (colorActual.equals(color)) {
                                consecutivosCPU++;
                            } else {
                                consecutivosOponente++;
                            }
                        }
                    }
                }
                if (consecutivosCPU > 0 && consecutivosOponente == 0) {
                    puntaje += Math.pow(10, consecutivosCPU);
                } else if (consecutivosOponente > 0 && consecutivosCPU == 0) {
                    puntaje -= Math.pow(10, consecutivosOponente);
                }
            }
        }

        return puntaje;
    }


}
