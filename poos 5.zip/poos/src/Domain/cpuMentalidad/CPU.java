package Domain.cpuMentalidad;

import Domain.elementos.elemento;

public interface CPU {
    void actuar(elemento[][] posiciones);
}
