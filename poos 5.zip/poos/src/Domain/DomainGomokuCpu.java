package Domain;

import Domain.cpuMentalidad.*;
import controller.GomokuController;
import Domain.cpuMentalidad.CPU;
import Domain.elementos.fichas.Token;
import Domain.elementos.elemento;

public class DomainGomokuCpu extends DomainGomoku{
    private String juego,mentalidad;
    private CPU maquina;
    public DomainGomokuCpu(GomokuController control,String juego,String maquina){
        super(control);
        this.juego=juego;
        mentalidad = maquina;
        inicializarCpu();
    }

    @Override
    public void actualizarMatriz(elemento[][] posiciones,int turno) {
        this.posiciones = posiciones;
        this.turno = turno;
        ponerToken();
        verificador();
        temporal();
    }

    public void ponerFicha(int i, int j,Token Ficha){
        posiciones[i][j] = Ficha;
        control.enviarMatriz(posiciones);
        control.cambioDeTurno();
    }
    public void ponerToken(){
        maquina.actuar(posiciones);
    }
    public void inicializarCpu(){
        if(juego.equals("Fichas Limitadas")){
            maquina = (CPU) new cpuConFichasLimitadas(this,mentalidad);
        }
        else{
            maquina = (CPU) new cpuConTodasLasFichas(this,mentalidad);
        }
    }

    public void turnoCpu(){

    }
}
