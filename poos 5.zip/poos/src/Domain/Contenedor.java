package Domain;
import java.io.Serializable;
import presentacion.juego.GomokuJuego;
public class Contenedor implements Serializable {
    private GomokuJuego gomokuJuego;
    private DomainGomoku domain;

    public Contenedor(GomokuJuego gomokuJuego, DomainGomoku domain) {
        this.gomokuJuego = gomokuJuego;
        this.domain = domain;
    }

    public GomokuJuego getGomokuJuego() {
        return gomokuJuego;
    }

    public DomainGomoku getDomainGomoku() {
        return domain;
    }

    public void refresh(){
        gomokuJuego.setVisible(true);
    }


}