package Domain.elementos.fichas;
import Domain.elementos.elemento;
import javax.swing.*;
import java.io.Serializable;
public class Token implements elemento,Serializable{
    private int i,j;
    protected String color;
    protected ImageIcon imagen;
    protected String url;
    private int valor=1;
    /**
     * Ficha normal
     */
    public Token(int i, int j , String color){
        this.i=i;
        this.j=j;
        this.color = color;
        preparedIcon();
    }
    public elemento[][] actuar(elemento[][] posiciones){
        return null;
    }
    public void preparedUrl() {
        if (getColor().equals("negro")) {
            url = "icons/fichas/negras/fichanormalnegra.png";
        } else {
            url = "icons/fichas/blancas/fichas-removebg-preview.png";
        }
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getValor() {
        return valor;
    }

    public void preparedIcon() {
        preparedUrl();
        imagen = new ImageIcon(url);
    }

    public String getUrl() {
        return url;
    }

    public ImageIcon getImagen() {
        return imagen;
    }

    public String getColor() {
        return color;
    }

    public int getI() {
        return i;
    }

    public int getJ() {
        return j;
    }
    public elemento[][] actuar(elemento[][] posiciones, Token ficha){
        return null;
    }

}