package Domain.elementos.fichas;

import javax.swing.*;

public class temporal extends Token {
    private int vida;
    private int valor=1;

    public temporal(int i, int j, String color) {
        super(i, j, color);
        preparedIcon();
        vida = 4;
    }

    @Override
    public void preparedUrl() {
        super.preparedUrl();
        if (getColor().equals("negro")) {
            url = "icons/fichas/negras/ficha_temporal_negra.png";
        } else {
            url = "icons/fichas/blancas/blanca_temporal.png";
        }
    }

    @Override
    public void preparedIcon() {
        preparedUrl();
        imagen = new ImageIcon(url);
    }

    public int getVida() {
        return vida;
    }

    public void sumaOne() {
        if (vida > 0) {
            vida--;
        } else {
            remove();
        }
    }

    public void remove() {
            System.out.println("Temporal eliminada después de tres turnos.");
    }
}
