package Domain.elementos.fichas;
import javax.swing.*;

public class pesada extends Token {
    private int valor=2;

    public pesada(int i, int j, String color) {
        super(i, j, color);
        preparedIcon();
    }
    @Override
    public void preparedUrl() {
        if (getColor().equals("negro")) {
            url = "icons/fichas/negras/fichas_pesada_negra.png";
        } else {
            url = "icons/fichas/blancas/blanca_pesada.png";
        }
    }

    public void preparedIcon() {
        preparedUrl();
        imagen = new ImageIcon(url);
    }
    @Override
    public int getValor() {
        return 2;
    }
}
