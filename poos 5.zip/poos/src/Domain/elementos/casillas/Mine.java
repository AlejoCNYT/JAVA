package Domain.elementos.casillas;
import Domain.elementos.elemento;
import Domain.elementos.fichas.Token;
import java.util.HashMap;
import javax.swing.*;

public class Mine extends Casilla{
    private HashMap<String, Integer> puntajes = new HashMap<>();
    public Mine(int i,int j){
        super(i,j);
    }
    @Override
    public elemento[][] actuar(elemento[][] posiciones,Token ficha) {
        JOptionPane.showMessageDialog(null, "BOOM", "Error", JOptionPane.ERROR_MESSAGE);
        try {
            if (esIndiceValido(i, j,posiciones)) posiciones[i][j] = null;
            if (esIndiceValido(i - 1, j - 1,posiciones)) posiciones[i - 1][j - 1] = null;
            if (esIndiceValido(i - 1, j,posiciones)) posiciones[i - 1][j] = null;
            if (esIndiceValido(i - 1, j + 1,posiciones)) posiciones[i - 1][j + 1] = null;
            if (esIndiceValido(i, j - 1,posiciones)) posiciones[i][j - 1] = null;
            if (esIndiceValido(i, j + 1,posiciones)) posiciones[i][j + 1] = null;
            if (esIndiceValido(i + 1, j - 1,posiciones)) posiciones[i + 1][j - 1] = null;
            if (esIndiceValido(i + 1, j,posiciones)) posiciones[i + 1][j] = null;
            if (esIndiceValido(i + 1, j + 1,posiciones)) posiciones[i + 1][j + 1] = null;
        } catch (ArrayIndexOutOfBoundsException e) {

        }

        return posiciones;
    }
    public HashMap<String, Integer> calcularPuntaje(elemento[][] posiciones,int turno) {
        int contadorBlancas = 0;
        int contadorNegras = 0;
        for (int filaAdyacente = i - 1; filaAdyacente <= i + 1; filaAdyacente++) {
            for (int columnaAdyacente = j - 1; columnaAdyacente <= j + 1; columnaAdyacente++) {
                if (esIndiceValido(filaAdyacente, columnaAdyacente, posiciones)) {
                    elemento elementoAdyacente = posiciones[filaAdyacente][columnaAdyacente];
                    if (elementoAdyacente instanceof Token) {
                        Token tokenAdyacente = (Token) elementoAdyacente;
                        if ("blanco".equals(tokenAdyacente.getColor())) {
                            contadorBlancas+=100;
                        } else if ("negro".equals(tokenAdyacente.getColor())) {
                            contadorNegras+=100;
                        }
                    }
                }
            }
        }
        return enviarPuntaje(turno,contadorBlancas,contadorNegras);
    }

    public HashMap<String, Integer> enviarPuntaje(int turno, int contadorBlancas, int contadorNegras) {
        int puntajeSuma, puntajeResta;
        HashMap<String, Integer> puntajes = new HashMap<>();
        if (turno == 1) {
            puntajeSuma = contadorBlancas;
            puntajeResta = -contadorNegras / 2;
        } else {
            puntajeSuma = contadorNegras;
            puntajeResta = -contadorBlancas / 2;
        }
        puntajes.put("blanco", puntajeSuma);
        puntajes.put("negro", puntajeResta);
        return puntajes;
    }



    private boolean esIndiceValido(int fila, int columna,elemento[][] posiciones) {
        return fila >= 0 && fila < posiciones.length && columna >= 0 && columna < posiciones[0].length;
    }
}
