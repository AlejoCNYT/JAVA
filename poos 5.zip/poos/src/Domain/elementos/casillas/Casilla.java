package Domain.elementos.casillas;
import Domain.elementos.elemento;
import Domain.elementos.fichas.Token;
import java.io.Serializable;
import javax.swing.*;

public class Casilla implements elemento,Serializable{
    int i,j;
    public Casilla(int i, int j){
        this.i=i;
        this.j=j;
    }
    @Override
    public elemento[][] actuar(elemento[][] posiciones,Token ficha){
        return posiciones;
    }
    public ImageIcon getImagen() {
        return null;
    }
    public int getValor(){
        return 1;
    }
    public String getColor(){
        return null;
    }

    @Override
    public int getI() {
        return i;
    }

    @Override
    public int getJ() {
        return j;
    }
}
