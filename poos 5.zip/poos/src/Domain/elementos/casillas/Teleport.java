package Domain.elementos.casillas;

import Domain.elementos.elemento;
import Domain.elementos.fichas.Token;

import javax.swing.*;
import java.util.Random;

public class Teleport extends Casilla{
    private Token ficha;
    public Teleport(int i, int j){
        super(i,j);
        this.ficha=ficha;
    }
    @Override
    public elemento[][] actuar(elemento[][] posiciones,Token ficha) {
        JOptionPane.showMessageDialog(null, "Teleport", "Error", JOptionPane.ERROR_MESSAGE);
        posiciones[i][j]=null;
        i = new Random().nextInt(posiciones.length-1);
        j = new Random().nextInt(posiciones.length-1);
        posiciones[i][j]=ficha;
        return posiciones;
    }


}
