package Domain.elementos.casillas;

import Domain.elementos.elemento;
import Domain.elementos.fichas.Token;
import Domain.elementos.fichas.pesada;
import Domain.elementos.fichas.temporal;
import java.util.Random;

public class Golden extends Casilla{
    public Golden(int i, int j){
        super(i,j);
    }
    @Override
    public elemento[][] actuar(elemento[][] posiciones, Token ficha){
        return posiciones;
    }
    public static Token aleatorio(int turno) {
        String color;
        if(turno==1){
            color = "blanco";
        }
        else{
            color = "negro";
        }
        Token[] tiposDeToken = {new temporal(0,0,color), new pesada(0,0,color)};

        Random random = new Random();
        int indiceAleatorio = random.nextInt(tiposDeToken.length);

        return tiposDeToken[indiceAleatorio];
    }
}
