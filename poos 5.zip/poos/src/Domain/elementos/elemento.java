package Domain.elementos;
import Domain.elementos.fichas.Token;

import javax.swing.*;

public interface elemento {
    elemento[][] actuar(elemento[][] posiciones, Token ficha);
    ImageIcon getImagen();
    int getValor();
    String getColor();
    int getI();
    int getJ();
};
