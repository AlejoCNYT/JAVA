package presentacion.mensajes;
import presentacion.GOMOKUGUI;
import presentacion.configuraciones.PanelRedondeado;
import presentacion.configuraciones.confi;
import presentacion.juego.GomokuJuego;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;

public class Empate extends JFrame {
    private PanelRedondeado panel;
    private GOMOKUGUI game;

    public Empate() {
        super();
        setUndecorated(true);
        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        preparedElements();
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 47, 47));
        setVisible(true);
    }

    public void preparedElements() {
        panel = new PanelRedondeado();
        panel.setBackground(new Color(14, 19, 49));
        titulo();
        botonAceptar();
        add(panel);
    }

    public void titulo() {
        JLabel labelTitulo = new JLabel("¡Empate!");
        labelTitulo.setFont(new Font("Showcard Gothic", Font.BOLD, 36));
        Color color = new Color(140, 169, 183);
        labelTitulo.setForeground(color);
        labelTitulo.setBounds(120, 40, 300, 70);

        panel.setLayout(null);
        panel.setPreferredSize(new Dimension(400, 200));
        panel.add(labelTitulo);
    }

    public void botonAceptar() {
        JButton botonAceptar = new JButton("Aceptar");
        botonAceptar.setBounds(150, 140, 100, 30);
        botonAceptar.setForeground(Color.white);
        botonAceptar.setBackground(new Color(208, 1, 53));
        botonAceptar.setBorderPainted(false);
        botonAceptar.setFocusPainted(false);


        botonAceptar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonAceptar.setBackground(new Color(238, 44, 44));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonAceptar.setBackground(new Color(208, 1, 53));
            }
        });

        botonAceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                game = new GOMOKUGUI();
                game.setVisible(true);
            }
        });
        panel.add(botonAceptar);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Empate ventana = new Empate();
                ventana.setVisible(true);
            }
        });
    }
}
