package presentacion.mensajes;

import presentacion.configuraciones.PanelRedondeado;
import Domain.elementos.fichas.Token;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;

public class MensajeGolden extends JFrame {
    protected PanelRedondeado panel;
    protected JLabel labelImagen;
    protected Token ficha;
    public MensajeGolden(Token ficha){
        super();
        this.ficha=ficha;
        setUndecorated(true);
        setSize(400, 280);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        preparedElements();
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 47, 47));
        setVisible(true);
    }
    public void preparedElements() {
        panel = new PanelRedondeado();
        panel.setBackground(new Color(14, 19, 49));
        titulo();
        botonAceptar();
        add(panel);
    }

    public void titulo() {
        JLabel labelTitulo = new JLabel("casilla golden");
        labelTitulo.setFont(new Font("Showcard Gothic", Font.BOLD, 30));
        Color color = new Color(140, 169, 183);
        labelTitulo.setForeground(color);
        labelTitulo.setBounds(80, 20, 300, 50);

        JLabel labelTitulo2 = new JLabel("!ganaste una ficha¡");
        labelTitulo2.setFont(new Font("Showcard Gothic", Font.BOLD, 25));
        labelTitulo2.setForeground(color);
        labelTitulo2.setBounds(70, 60, 300, 50);

        labelImagen = new JLabel(new ImageIcon(ficha.getUrl()));
        labelImagen.setBounds(120, 140, 160, 60);

        panel.setLayout(null);
        panel.setPreferredSize(new Dimension(400, 200));
        panel.add(labelTitulo);
        panel.add(labelTitulo2);
        panel.add(labelImagen);
    }
    public void botonAceptar() {
        JButton botonAceptar = new JButton("Aceptar");
        botonAceptar.setBounds(150, 220, 100, 30);
        botonAceptar.setForeground(Color.white);
        botonAceptar.setBackground(new Color(208, 1, 53));
        botonAceptar.setBorderPainted(false);
        botonAceptar.setFocusPainted(false);


        botonAceptar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonAceptar.setBackground(new Color(238, 44, 44));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonAceptar.setBackground(new Color(208, 1, 53));
            }
        });

        botonAceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        panel.add(botonAceptar);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Token ficha = new Token(0,0,"blanco");
                MensajeGolden ventana = new MensajeGolden(ficha);
                ventana.setVisible(true);
            }
        });
    }

}
