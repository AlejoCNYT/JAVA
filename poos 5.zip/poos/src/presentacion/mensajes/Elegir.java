package presentacion.mensajes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import presentacion.configuraciones.PanelRedondeado;
import Domain.elementos.fichas.Token;
import Domain.elementos.fichas.*;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class Elegir extends JFrame {
    private JButton fichaNormal, fichaTemporal, fichaPesada;
    private PanelRedondeado panel;
    private Token normal;
    private pesada pesada;
    private temporal temporal;
    private String color;
    private Token eleccion;
    private int i,j;

    public Elegir(int i, int j,String color) {
        super();
        this.i=i;
        this.j=j;
        this.color = color;
        setUndecorated(true);
        setSize(300, 150);
        setLocationRelativeTo(null);
        preparedElements();
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 47, 47));
        setVisible(true);
    }

    public Token getEleccion() {
        return eleccion;
    }

    public void preparedElements() {
        panel = new PanelRedondeado();
        panel.setLayout(null);
        panel.setBackground(new Color(14, 19, 49));
        preparedButtons();
        titulo();
        add(panel);
    }

    public void preparedButtons() {
        fichaNormal = new JButton();
        fichaNormal.setBounds(70, 80, 30, 30);

        fichaTemporal = new JButton();
        fichaTemporal.setBounds(140, 80, 30, 30);

        fichaPesada = new JButton();
        fichaPesada.setBounds(210, 80, 30, 30);

        preparedIcons();
        panel.add(fichaNormal);
        panel.add(fichaTemporal);
        panel.add(fichaPesada);
    }
    public void preparedIcons() {
        normal = new Token(i, j, color);
        pesada = new pesada(i, j, color);
        temporal = new temporal(i, j, color);

        fichaNormal.setIcon(normal.getImagen());
        fichaPesada.setIcon(pesada.getImagen());
        fichaTemporal.setIcon(temporal.getImagen());

        fichaNormal.setBorderPainted(false);
        fichaPesada.setBorderPainted(false);
        fichaTemporal.setBorderPainted(false);

        fichaNormal.setContentAreaFilled(false);
        fichaPesada.setContentAreaFilled(false);
        fichaTemporal.setContentAreaFilled(false);

        lissener();
    }


    public void lissener() {
        fichaNormal.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eleccion = normal;
                dispose();
            }
        });
        fichaTemporal.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eleccion = temporal;
                dispose();
            }
        });
        fichaPesada.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eleccion = pesada;
                dispose();
            }
        });
    }
    public void titulo() {
        JLabel labelTitulo = new JLabel("¿que ficha vas a poner?");
        labelTitulo.setFont(new Font("Showcard Gothic", Font.BOLD, 20));
        Color color = new Color(140, 169, 183);
        labelTitulo.setForeground(color);
        labelTitulo.setBounds(25, 20, 300, 50);
        tituloNormal();
        tituloPesada();
        tituloTemporal();
        panel.setLayout(null);
        panel.setPreferredSize(new Dimension(400, 200));
        panel.add(labelTitulo);
    }

    public void tituloNormal() {
        JLabel tituloNormal = new JLabel("normal");
        tituloNormal.setFont(new Font("Showcard Gothic", Font.BOLD, 13));
        tituloNormal.setForeground(Color.white);
        tituloNormal.setBounds(50, 106, 300, 50);
        panel.add(tituloNormal);
    }

    public void tituloTemporal() {
        JLabel tituloNormal = new JLabel("temporal");
        tituloNormal.setFont(new Font("Showcard Gothic", Font.BOLD, 13));
        tituloNormal.setForeground(Color.white);
        tituloNormal.setBounds(115, 106, 300, 50);
        panel.add(tituloNormal);
    }

    public void tituloPesada() {
        JLabel tituloNormal = new JLabel("pesada");
        tituloNormal.setFont(new Font("Showcard Gothic", Font.BOLD, 13));
        tituloNormal.setForeground(Color.white);
        tituloNormal.setBounds(200, 106, 300, 50);
        panel.add(tituloNormal);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Elegir num = new Elegir(0,0,"negro");
            num.setVisible(true);
        });
    }
}
