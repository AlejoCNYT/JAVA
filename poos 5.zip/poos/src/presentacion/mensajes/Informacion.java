package presentacion.mensajes;

import presentacion.configuraciones.PanelRedondeado;
import Domain.elementos.fichas.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;
import java.text.DecimalFormat;
import java.util.Map;
import excepciones.*;

public class Informacion extends JFrame {
    private PanelRedondeado panel;
    private JLabel marcadorNormal, marcadorPesada, marcadorTemporal,labelTiempo;
    private String ganador;
    private JPanel normalPanel, pesadaPanel, temporalPanel;
    private String imageFichaNegra, imageFichaBlanca;
    private ImageIcon imageIconFichaNegra, imageIconFichaBlanca;
    private String color;
    private Token normalToken;
    private temporal temporalToken;
    private pesada pesadaToken;
    private Map<String, Integer> numeroToken;
    private Timer temporizador;
    private int segundosTranscurridos;

    public Informacion(String ganador, int x, int y, String color, Map<String, Integer> numeroToken) {
        super();
        this.numeroToken = numeroToken;
        this.color = color;
        this.ganador = ganador;
        setUndecorated(true);
        setSize(230, 220);
        preparedElements();
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 47, 47));
        preparedPosicion(x, y);
        prepareteTemporizador();
    }
    public void imprimirHash() {
        for (Map.Entry<String, Integer> entry : numeroToken.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
    public void prepareteTemporizador(){
        labelTiempo = new JLabel("00:00");
        labelTiempo.setFont(new Font("Showcard Gothic", Font.BOLD, 26));
        labelTiempo.setForeground(Color.WHITE);
        labelTiempo.setBounds(80, 170, 200, 50);
        panel.add(labelTiempo);

        temporizador = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                segundosTranscurridos++;
                actualizarLabelTiempo();
            }
        });
    }
    private void actualizarLabelTiempo() {
        int minutos = segundosTranscurridos / 60;
        int segundos = segundosTranscurridos % 60;
        DecimalFormat formato = new DecimalFormat("00");
        labelTiempo.setText(formato.format(minutos) + ":" + formato.format(segundos));
    }

    public void iniciarTemporizador() {
        temporizador.start();
    }

    public void detenerTemporizador() {
        if (temporizador != null) {
            temporizador.stop();
        }
    }

    public void preparedPosicion(int x, int y) {
        setLocation(x, y);
    }

    public void preparedElements() {
        panel = new PanelRedondeado();
        preparedIcons();
        panel.setBackground(new Color(14, 19, 49));
        titulo();
        tituloNormal();
        tituloTemporal();
        tituloPesada();
        add(panel);
    }
    public void tituloNormal() {
        JLabel tituloNormal = new JLabel("normal");
        tituloNormal.setFont(new Font("Showcard Gothic", Font.BOLD, 13));
        tituloNormal.setForeground(Color.white);
        tituloNormal.setBounds(20, 100, 300, 50);
        panel.add(tituloNormal);
    }

    public void tituloTemporal() {
        JLabel tituloNormal = new JLabel("temporal");
        tituloNormal.setFont(new Font("Showcard Gothic", Font.BOLD, 13));
        tituloNormal.setForeground(Color.white);
        tituloNormal.setBounds(80, 100, 300, 50);
        panel.add(tituloNormal);
    }

    public void tituloPesada() {
        JLabel tituloNormal = new JLabel("pesada");
        tituloNormal.setFont(new Font("Showcard Gothic", Font.BOLD, 13));
        tituloNormal.setForeground(Color.white);
        tituloNormal.setBounds(160, 100, 300, 50);
        panel.add(tituloNormal);
    }

    public void iconos() {
        normalToken = new Token(0, 0, color);
        temporalToken = new temporal(0, 0, color);
        pesadaToken = new pesada(0, 0, color);
    }

    public void preparedIcons() {
        iconos();
        preparedMarcador();
        normalPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(normalToken.getImagen().getImage(), 0, 0, getWidth(), getHeight(), this);
            }
        };

        temporalPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(temporalToken.getImagen().getImage(), 0, 0, getWidth(), getHeight(), this);
            }
        };

        pesadaPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(pesadaToken.getImagen().getImage(), 0, 0, getWidth(), getHeight(), this);
            }
        };


        organizar();
        panel.add(normalPanel);
        panel.add(pesadaPanel);
        panel.add(temporalPanel);
    }

    public void preparedMarcador(){
        String normal = String.valueOf(numeroToken.get("normal"));
        String pesada = String.valueOf(numeroToken.get("pesada"));
        String temporal = String.valueOf(numeroToken.get("temporal"));

        marcadorNormal = new JLabel(normal);
        marcadorNormal.setBounds(39, 135, 100, 52);
        marcadorNormal.setFont(new Font("Showcard Gothic", Font.BOLD, 30));
        marcadorNormal.setForeground(Color.WHITE);
        marcadorNormal.setText(normal);

        marcadorPesada = new JLabel(pesada);
        marcadorPesada.setBounds(170, 135, 100, 50);
        marcadorPesada.setFont(new Font("Showcard Gothic", Font.BOLD, 30));
        marcadorPesada.setForeground(Color.WHITE);
        marcadorPesada.setText(pesada);

        marcadorTemporal = new JLabel(temporal);
        marcadorTemporal.setBounds(104, 135, 100, 50);
        marcadorTemporal.setFont(new Font("Showcard Gothic", Font.BOLD, 30));
        marcadorTemporal.setForeground(Color.WHITE);
        marcadorTemporal.setText(temporal);
    }
    public void organizar() {
        normalPanel.setBounds(40, 80, 30, 30);
        normalPanel.setBackground(new Color(0, 0, 0, 0));
        temporalPanel.setBounds(100, 80, 30, 30);
        temporalPanel.setBackground(new Color(0, 0, 0, 0));
        pesadaPanel.setBounds(165, 80, 30, 30);
        pesadaPanel.setBackground(new Color(0, 0, 0, 0));
        numeros();
    }

    public void numeros() {
        panel.add(marcadorNormal);
        panel.add(marcadorPesada);
        panel.add(marcadorTemporal);
    }

    public void titulo() {
        JLabel labelGanador = new JLabel(ganador);
        labelGanador.setFont(new Font("Showcard Gothic", Font.BOLD, 30));
        Color color2 = new Color(172, 124, 183);
        labelGanador.setForeground(color2);

        Dimension size = labelGanador.getPreferredSize();
        int x = (getWidth() - size.width) / 2;
        int y = 25;
        labelGanador.setBounds(x, y, size.width, size.height);

        panel.setLayout(null);
        panel.setPreferredSize(new Dimension(300, 200));
        panel.add(labelGanador);
    }

    public void disminuirNormal() {
        try {
            int cantidadNormal = numeroToken.get("normal");
            if (cantidadNormal > 0) {
                numeroToken.put("normal", cantidadNormal - 1);
                refresh();
            } else {
                throw new ConfiguracionIncompletaException(ConfiguracionIncompletaException.no_found_token);
            }
        } catch (ConfiguracionIncompletaException e) {
            Log.registrarError("Error al disminuir normal", e);
            JOptionPane.showMessageDialog(null,  e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void disminuirTemporal() {
        try {
            int cantidadTemporal = numeroToken.get("temporal");
            if (cantidadTemporal > 0) {
                numeroToken.put("temporal", cantidadTemporal - 1);
                refresh();
            } else {
                throw new ConfiguracionIncompletaException(ConfiguracionIncompletaException.no_found_token);
            }
        } catch (ConfiguracionIncompletaException e) {
            Log.registrarError("Error al disminuir temporal", e);
            JOptionPane.showMessageDialog(null,e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void disminuirPesada() {
        try {
            int cantidadPesada = numeroToken.get("pesada");
            if (cantidadPesada > 0) {
                numeroToken.put("pesada", cantidadPesada - 1);
                refresh();
            } else {
                throw new ConfiguracionIncompletaException(ConfiguracionIncompletaException.no_found_token);
            }
        } catch (ConfiguracionIncompletaException e) {
            Log.registrarError("Error al disminuir pesada", e);
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    public void disminuir(Token ficha) {
        String tipoFicha = ficha.getClass().getSimpleName().toLowerCase();
        if (tipoFicha.equals("token")){
            disminuirNormal();
        }
        else if (tipoFicha.equals("pesada")) {
            disminuirPesada();
        } else if (tipoFicha.equals("temporal")) {
            disminuirTemporal();
        }
    }
    public void aumentarNormal() {
        try {
            int cantidadNormal = numeroToken.get("normal");
            if (cantidadNormal > 0) {
                numeroToken.put("normal", cantidadNormal + 1);
                refresh();
            } else {
                throw new ConfiguracionIncompletaException(ConfiguracionIncompletaException.no_found_token);
            }
        } catch (ConfiguracionIncompletaException e) {
            Log.registrarError("Error al aumentar normal", e);
            JOptionPane.showMessageDialog(null,  e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void aumentarTemporal() {
        try {
            int cantidadTemporal = numeroToken.get("temporal");
            if (cantidadTemporal > 0) {
                numeroToken.put("temporal", cantidadTemporal + 1);
                refresh();
            } else {
                throw new ConfiguracionIncompletaException(ConfiguracionIncompletaException.no_found_token);
            }
        } catch (ConfiguracionIncompletaException e) {
            Log.registrarError("Error al aumentar temporal", e);
            JOptionPane.showMessageDialog(null,e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void aumentarPesada() {
        try {
            int cantidadPesada = numeroToken.get("pesada");
            if (cantidadPesada > 0) {
                numeroToken.put("pesada", cantidadPesada + 1);
                refresh();
            } else {
                throw new ConfiguracionIncompletaException(ConfiguracionIncompletaException.no_found_token);
            }
        } catch (ConfiguracionIncompletaException e) {
            Log.registrarError("Error al aumentar pesada", e);
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    public void aumentar(Token ficha) {
        String tipoFicha = ficha.getClass().getSimpleName().toLowerCase();
        if (tipoFicha.equals("token")){
            aumentarNormal();
        }
        else if (tipoFicha.equals("pesada")) {
            aumentarPesada();
        } else if (tipoFicha.equals("temporal")) {
            aumentarTemporal();
        }
    }


    public void refresh(){
        String normal = String.valueOf(numeroToken.get("normal"));
        String pesada = String.valueOf(numeroToken.get("pesada"));
        String temporal = String.valueOf(numeroToken.get("temporal"));

        marcadorNormal.setText(normal);
        marcadorPesada.setText(pesada);
        marcadorTemporal.setText(temporal);
    }


    public static void main(String[] args) {
        Informacion ventana = new Informacion("santi", 10, 20, "negro",null);
        ventana.setVisible(true);
    }
}
