package presentacion.mensajes;

import Domain.elementos.fichas.Token;

import javax.swing.*;
import java.awt.*;

public class mensajeMilPuntos extends MensajeGolden{
    public mensajeMilPuntos(Token ficha){
        super(ficha);
    }
    @Override
    public void titulo() {
        JLabel labelTitulo = new JLabel("obtuviste mil puntos");
        labelTitulo.setFont(new Font("Showcard Gothic", Font.BOLD, 20));
        Color color = new Color(140, 169, 183);
        labelTitulo.setForeground(color);
        labelTitulo.setBounds(80, 20, 300, 50);

        JLabel labelTitulo2 = new JLabel("!ganaste una ficha¡");
        labelTitulo2.setFont(new Font("Showcard Gothic", Font.BOLD, 25));
        labelTitulo2.setForeground(color);
        labelTitulo2.setBounds(70, 60, 300, 50);

        labelImagen = new JLabel(new ImageIcon(ficha.getUrl()));
        labelImagen.setBounds(120, 140, 160, 60);

        panel.setLayout(null);
        panel.setPreferredSize(new Dimension(400, 200));
        panel.add(labelTitulo);
        panel.add(labelTitulo2);
        panel.add(labelImagen);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Token ficha = new Token(0,0,"blanco");
                mensajeMilPuntos ventana = new mensajeMilPuntos(ficha);
                ventana.setVisible(true);
            }
        });
    }
}
