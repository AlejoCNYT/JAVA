package presentacion.mensajes;

import presentacion.configuraciones.PanelRedondeado;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;

public class Ganar extends JFrame {
    private PanelRedondeado panel;
    private String ganador;

    public Ganar(String ganador) {
        super();
        setUndecorated(true);
        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.ganador = ganador;
        preparedElements();
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 47, 47));
        setVisible(true);
    }

    public void preparedElements() {
        panel = new PanelRedondeado();
        panel.setBackground(new Color(14, 19, 49));
        titulo();
        botonAceptar();
        add(panel);
    }

    public void titulo() {
        JLabel labelTitulo = new JLabel("¡Ganador!");
        labelTitulo.setFont(new Font("Showcard Gothic", Font.BOLD, 36));
        Color color = new Color(140, 169, 183);
        labelTitulo.setForeground(color);
        labelTitulo.setBounds(100, 20, 300, 50);

        JLabel labelGanador = new JLabel(ganador);
        labelGanador.setFont(new Font("Showcard Gothic", Font.BOLD, 30));
        Color color2 = new Color(172, 124, 183);
        labelGanador.setForeground(color2);

        Dimension size = labelGanador.getPreferredSize();
        int x = (getWidth() - size.width) / 2;
        int y = 80;
        labelGanador.setBounds(x, y, size.width, size.height);

        panel.setLayout(null);
        panel.setPreferredSize(new Dimension(400, 200));
        panel.add(labelTitulo);
        panel.add(labelGanador);
    }
    public void ganador(){
        JLabel labelTitulo = new JLabel(ganador);
        labelTitulo.setFont(new Font("Showcard Gothic", Font.BOLD, 36));
        Color color = new Color(140, 169, 183);
        labelTitulo.setForeground(color);
        labelTitulo.setBounds(120, 20, 300, 50);
    }

    public void botonAceptar() {
        JButton botonAceptar = new JButton("Aceptar");
        botonAceptar.setBounds(150, 140, 100, 30);
        botonAceptar.setForeground(Color.white);
        botonAceptar.setBackground(new Color(208, 1, 53));
        botonAceptar.setBorderPainted(false);
        botonAceptar.setFocusPainted(false);


        botonAceptar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonAceptar.setBackground(new Color(238, 44, 44));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonAceptar.setBackground(new Color(208, 1, 53));
            }
        });

        botonAceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        panel.add(botonAceptar);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Ganar ventana = new Ganar("santi");
                ventana.setVisible(true);
            }
        });
    }
}
