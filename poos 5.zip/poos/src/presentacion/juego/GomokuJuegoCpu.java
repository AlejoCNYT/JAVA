package presentacion.juego;

import excepciones.ConfiguracionIncompletaException;
import presentacion.GOMOKUGUI;
import presentacion.mensajes.Elegir;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class GomokuJuegoCpu extends  GomokuJuego{
    public GomokuJuegoCpu(String juego, String jugador, String maqui, String tablero, String nombre1, String nombre2,int tiempo){
        super(juego,jugador,maqui,tablero,nombre1,nombre2,tiempo,11);
    }
    @Override
    public void colocarFicha(int i, int j) {
        try {
            disminuir("blanco", escoger.getEleccion());
            if (posiciones[i][j] == null) {
                posiciones[i][j] = escoger.getEleccion();
                botones[i][j].setIcon(posiciones[i][j].getImagen());
                control.actualizarMatriz(posiciones,turno);
            } else {
                throw new ConfiguracionIncompletaException(ConfiguracionIncompletaException.pocision_ocupada);
            }
        } catch (ConfiguracionIncompletaException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            posiciones[i][j] = null;
            botones[i][j].setIcon(null);
        }
    }
   @Override
    public void bottonLiseng(int i, int j) {
        botones[i][j].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cambioDeTurno();
                escoger = new Elegir(i, j,  "blanco");
                escoger.addWindowListener(new WindowAdapter() {
                    @Override
                    public void windowClosed(WindowEvent e) {
                        colocarFicha(i,j);
                    }
                });
                escoger.setVisible(true);
            }
        });
    }
    @Override
    public void cambioDeTurno() {
        if (turno == 1) {
            informacion2.detenerTemporizador();
            informacion1.iniciarTemporizador();
            labelJugador2.setForeground(Color.GRAY);
            turno = 2;
            if(!Quicktime){
                marcadorJugador2.setForeground(Color.GRAY);
                marcadorJugador1.setForeground(new Color(179, 245, 240));
            }
            labelJugador1.setForeground(new Color(179, 245, 240));
            if (Quicktime) {
                detenerTemporizadorJugador2();
                iniciarTemporizadorJugador1();
            }
        } else {
            informacion1.detenerTemporizador();
            informacion2.iniciarTemporizador();
            labelJugador1.setForeground(Color.GRAY);
            turno = 1;
            if(!Quicktime){
                marcadorJugador1.setForeground(Color.GRAY);
                marcadorJugador2.setForeground(new Color(229, 203, 238));
            }
            labelJugador2.setForeground(new Color(229, 203, 238));
            if (Quicktime) {
                detenerTemporizadorJugador1();
                iniciarTemporizadorJugador2();
            }
        }
    }
}
