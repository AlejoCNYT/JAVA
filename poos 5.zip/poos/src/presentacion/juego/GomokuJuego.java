package presentacion.juego;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Domain.elementos.casillas.Golden;
import controller.*;
import excepciones.ConfiguracionIncompletaException;
import excepciones.Log;
import presentacion.configuraciones.settings;
import presentacion.mensajes.Elegir;
import presentacion.mensajes.Ganar;
import presentacion.mensajes.Informacion;
import presentacion.configuraciones.PanelRedondeado;
import Domain.elementos.fichas.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.Timer;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import Domain.elementos.*;
import Domain.elementos.casillas.Casilla;
import presentacion.mensajes.*;


public class GomokuJuego extends JFrame implements Serializable {
    protected PanelRedondeado panel;
    protected JButton[][] botones;
    protected elemento[][] posiciones; // matriz que se pasa
    protected String jugador, maquina, juego, tablero, nombre1, nombre2;
    protected int tamañoTablero,turno,segundosTranscurridos;
    protected int puntosJugador1=0;
    protected int PuntosJugador2=0;
    private String Ganador;
    protected GomokuController control;
    protected JLabel labelTiempo,labelTiempoQuicktime1,labelTiempoQuicktime2,labelJugador1,labelJugador2;
    protected JLabel marcadorJugador1,marcadorJugador2;
    private Timer temporizador,temporizadorJugador1,temporizadorJugador2;
    private int segundosTotales,segundosTotales2,tiempo,fichasEspeciales;
    protected boolean Quicktime;
    protected Informacion informacion1,informacion2;
    private Map<String, Integer> numeroTokenBlancas,numeroTokenNegras;
    protected Elegir escoger;

    public GomokuJuego(String juego, String jugador, String maqui, String tablero, String nombre1, String nombre2,int segundos, int fichasEspeciales) {
        super();
        Log.configurarLog();
        this.fichasEspeciales = fichasEspeciales;
        System.out.println(fichasEspeciales);
        segundosTotales = segundos;
        segundosTotales2 = segundos;
        tiempo = segundos;
        tamañoTablero = Integer.parseInt(tablero.split("x")[0]);
        maquina = maqui;
        this.jugador = jugador;
        this.juego = juego;
        this.tablero = tablero;
        this.nombre1 = nombre1;
        this.nombre2 = nombre2;
        preparedTablero();
        preparedPanel();
        preparaMatrizBotones();
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 47, 47));
        if (juego.equals("Quicktime")) {
            Quicktime = true;
            this.numeroTokenBlancas = generateTokensBlancas();
            this.numeroTokenNegras = generateTokensNegras();
            preparedInformacion();
            preparedInfo();
        }
        else if (!juego.equals("Fichas Limitadas")) {
            this.numeroTokenBlancas = generateTokensBlancas();
            this.numeroTokenNegras = generateTokensNegras();
            preparedInfo();
            preparedInformacion();
        }
        else {
            Quicktime = false;
        }

        settings();
    }

    public elemento[][] getPosiciones() {
        return posiciones;
    }

    public int getFichasEspeciales() {
        return fichasEspeciales;
    }

    public int getTiempo() {
        return tiempo;
    }

    public String getJugador() {
        return jugador;
    }

    public String getMaquina() {
        return maquina;
    }

    public String getJuego() {
        return juego;
    }

    public String getTablero() {
        return tablero;
    }

    public String getNombre1() {
        return nombre1;
    }

    public String getNombre2() {
        return nombre2;
    }

    public int getPuntosJugador1() {
        return puntosJugador1;
    }

    public int getPuntosJugador2() {
        return PuntosJugador2;
    }

    private void preparedPanel(){
        panel = new PanelRedondeado();
        panel.setBackground(new Color(14, 19, 49));
    }

    public void prepareteTemporizadorQuicktime1() {
        int minutos = tiempo / 60;
        int segundos = tiempo % 60;
        DecimalFormat formato = new DecimalFormat("00");
        String time = (formato.format(minutos) + ":" + formato.format(segundos));

        labelTiempoQuicktime1 = new JLabel(time);
        labelTiempoQuicktime1.setFont(new Font("Showcard Gothic", Font.BOLD, 38));
        labelTiempoQuicktime1.setForeground(Color.WHITE);
        labelTiempoQuicktime1.setBounds(120, 140, 200, 50);
        panel.add(labelTiempoQuicktime1);

        temporizadorJugador1 = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (segundosTotales > 0) {
                    segundosTotales--;
                    actualizarLabelTiempoQuicktime1();
                } else {
                    detenerTemporizadorJugador1();
                    Ganador = nombre2;
                    ganar(Ganador);
                    desabilitarNombres();
                    deshabilitarBotones();
                }
            }
        });
    }
    public int getFichas() {
        return 50;
    }

    public void prepareteTemporizadorQuicktime2() {
        int minutos = tiempo / 60;
        int segundos = tiempo % 60;
        DecimalFormat formato = new DecimalFormat("00");
        String time = (formato.format(minutos) + ":" + formato.format(segundos));

        labelTiempoQuicktime2 = new JLabel(time);
        labelTiempoQuicktime2.setFont(new Font("Showcard Gothic", Font.BOLD, 38));
        labelTiempoQuicktime2.setForeground(Color.WHITE);
        labelTiempoQuicktime2.setBounds(430, 140, 200, 50);
        panel.add(labelTiempoQuicktime2);

        temporizadorJugador2 = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (segundosTotales2 > 0) {
                    segundosTotales2--;
                    actualizarLabelTiempoQuicktime2();
                } else{
                    detenerTemporizadorJugador2();
                    Ganador = nombre1;
                    ganar(Ganador);
                    desabilitarNombres();
                    deshabilitarBotones();
                }
            }
        });
    }

    private void actualizarLabelTiempoQuicktime1() {
        int minutos = segundosTotales / 60;
        int segundos = segundosTotales % 60;
        DecimalFormat formato = new DecimalFormat("00");
        labelTiempoQuicktime1.setText(formato.format(minutos) + ":" + formato.format(segundos));
    }

    private void actualizarLabelTiempoQuicktime2() {
        int minutos = segundosTotales2 / 60;
        int segundos = segundosTotales2 % 60;
        DecimalFormat formato = new DecimalFormat("00");
        labelTiempoQuicktime2.setText(formato.format(minutos) + ":" + formato.format(segundos));
    }

    public void iniciarTemporizadorJugador1() {
        temporizadorJugador1.start();
    }

    public void detenerTemporizadorJugador1() {
        temporizadorJugador1.stop();
    }

    public void iniciarTemporizadorJugador2() {
        temporizadorJugador2.start();
    }

    public void detenerTemporizadorJugador2() {
        temporizadorJugador2.stop();
    }

    public void preparedTablero(){
        botones = new JButton[tamañoTablero][tamañoTablero];
        posiciones = new elemento[tamañoTablero][tamañoTablero];
        control=new GomokuController(this,tamañoTablero,jugador,juego,maquina);
        posiciones = control.inicializarJuego(tamañoTablero);
        imprimirMatriz();
        turno = 1;
    }


    public void prepareteTemporizador(){
        labelTiempo = new JLabel("00:00");
        labelTiempo.setFont(new Font("Showcard Gothic", Font.BOLD, 38));
        labelTiempo.setForeground(Color.WHITE);
        labelTiempo.setBounds(270, 140, 200, 50);
        panel.add(labelTiempo);

        temporizador = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                segundosTranscurridos++;
                actualizarLabelTiempo();
            }
        });
    }

    public void iniciarTemporizador() {
        temporizador.start();
    }

    public void detenerTemporizador() {
        if (temporizador != null) {
            temporizador.stop();
        }
    }
    private void actualizarLabelTiempo() {
        int minutos = segundosTranscurridos / 60;
        int segundos = segundosTranscurridos % 60;
        DecimalFormat formato = new DecimalFormat("00");
        labelTiempo.setText(formato.format(minutos) + ":" + formato.format(segundos));
    }

    public void imprimirMatriz() {
        for (int i = 0; i < posiciones.length; i++) {
            for (int j = 0; j < posiciones[0].length; j++) {
                System.out.print(posiciones[i][j] + "\t");
            }
            System.out.println();
        }
    }


    public void preparateElements() {
        setUndecorated(true);
        setSize(650, 760);
        setLocationRelativeTo(null);
        titulo();
        jugador1();
        jugador2();

        if (juego != null && !juego.equals("Quicktime")) {
            marcadorJugador2();
            marcadorJugador1();
            prepareteTemporizador();
            iniciarTemporizador();
        }
        else {
            prepareteTemporizadorQuicktime1();
            prepareteTemporizadorQuicktime2();
        }
        preparaBotonCerrar();
        add(panel);
    }
    public Map<String, Integer>  generateTokensBlancas(){
        return control.generateTokesBlancas(fichasEspeciales);
    }
    public Map<String, Integer>  generateTokensNegras(){
        return control.generateTokesNegras(fichasEspeciales);
    }
    public void preparedInfo() {
        informacion1 = new Informacion(nombre1, 400, 150, "blanco", numeroTokenBlancas);
        informacion2 = new Informacion(nombre2, 700, 150, "negro", numeroTokenNegras);
    }
    public void imprimirHash() {
        for (Map.Entry<String, Integer> entry : numeroTokenNegras.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

    public void titulo(){
        JLabel labelTitulo = new JLabel("Gomoku");
        labelTitulo.setFont(new Font("Showcard Gothic", Font.BOLD, 36));
        labelTitulo.setForeground(Color.WHITE);
        labelTitulo.setBounds(250, 20, 300, 50);

        panel.setLayout(null);
        panel.setPreferredSize(new Dimension(500, 700));
        panel.add(labelTitulo);
    }

    public void jugador2() {
        labelJugador2 = new JLabel(nombre2);
        labelJugador2.setFont(new Font("Showcard Gothic", Font.BOLD, 24));
        labelJugador2.setForeground(new Color(229, 203, 238));

        Dimension size = labelJugador2.getPreferredSize();
        int x = 280 + (400 - size.width) / 2;
        labelJugador2.setBounds(x, 100, size.width, size.height);

        panel.add(labelJugador2);
    }
    public void marcadorJugador2() {
        marcadorJugador2 = new JLabel(String.valueOf(PuntosJugador2));
        marcadorJugador2.setFont(new Font("Showcard Gothic", Font.BOLD, 34));
        marcadorJugador2.setForeground(new Color(229, 203, 238));
        marcadorJugador2.setBounds(470, 140, 400, 50);
        panel.add(marcadorJugador2);
    }
    public void marcadorJugador1() {
        marcadorJugador1 = new JLabel(String.valueOf(puntosJugador1));
        marcadorJugador1.setFont(new Font("Showcard Gothic", Font.BOLD, 34));
        marcadorJugador1.setForeground(new Color(179, 245, 240));
        marcadorJugador1.setBounds(150, 140, 400, 50);
        panel.add(marcadorJugador1);
    }
    public void sumaFichaEspecial(){
        if(turno==1){
            puntosJugador1 +=100;
            if(puntosJugador1>=1000){
                reinicio1();
                registrarPremio();
            }
            if(!Quicktime){
                marcadorJugador1.setText(String.valueOf(puntosJugador1));
            }
        }
        else if(turno==2){
            PuntosJugador2 += 100;
            if(PuntosJugador2 >= 1000){
                reinicio2();
                registrarPremio();
            }
            if(!Quicktime){
                marcadorJugador2.setText(String.valueOf(PuntosJugador2));
            }

        }
    }

    public void reinicio1(){
        puntosJugador1 = 0;
        marcadorJugador1.setText(String.valueOf(puntosJugador1));
    }
    public void reinicio2(){
        PuntosJugador2 = 0;
        marcadorJugador2.setText(String.valueOf(PuntosJugador2));
    }
    public void registrarPremio(){
        Token ficha = Golden.aleatorio(turno);
        premioDeFicha(ficha);
        informacion1.aumentar(ficha);
    }

    public void premioDeFicha(Token ficha){
        mensajeMilPuntos ventana = new mensajeMilPuntos(ficha);
        ventana.setVisible(true);
    }

    public void setPuntaje(int puntos1,int puntos2){
        puntosJugador1 = puntos1;
        PuntosJugador2 = puntos2;
        marcadorJugador1.setText(String.valueOf(puntosJugador1));
        marcadorJugador2.setText(String.valueOf(PuntosJugador2));
    }

    public void actualizarPuntajes(HashMap<String, Integer> puntuacion){
        if(!Quicktime){
            if(turno==1){
                puntosJugador1 += puntuacion.get("blanco") + puntuacion.get("negro");
                marcadorJugador1.setText(String.valueOf(puntosJugador1));
            }
            else if(turno==2){
                PuntosJugador2 += puntuacion.get("blanco") + puntuacion.get("negro");
                marcadorJugador2.setText(String.valueOf(PuntosJugador2));
            }
        }

    }
    public void jugador1() {
        labelJugador1 = new JLabel(nombre1);
        labelJugador1.setFont(new Font("Showcard Gothic", Font.BOLD, 24));
        labelJugador1.setForeground(new Color(179, 245, 240));

        Dimension size = labelJugador1.getPreferredSize();
        int x =  (400 - size.width) / 2 - 40;
        labelJugador1.setBounds(x, 100, size.width, size.height);

        panel.add(labelJugador1);
    }

    public void preparedInformacion() {

        labelJugador1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                informacion1.setVisible(true);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                informacion1.setVisible(false);
            }
        });
        labelJugador2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                informacion2.setVisible(true);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                informacion2.setVisible(false);
            }
        });
    }
    public void cambioDeTurno() {
        if (turno == 1) {
            informacion2.detenerTemporizador();
            informacion1.iniciarTemporizador();
            labelJugador2.setForeground(Color.GRAY);
            turno = 2;
            if(!Quicktime){
                marcadorJugador2.setForeground(Color.GRAY);
                marcadorJugador1.setForeground(new Color(179, 245, 240));
            }
            labelJugador1.setForeground(new Color(179, 245, 240));
            if (Quicktime) {
                detenerTemporizadorJugador2();
                iniciarTemporizadorJugador1();
            }
        } else {
            informacion1.detenerTemporizador();
            informacion2.iniciarTemporizador();
            labelJugador1.setForeground(Color.GRAY);
            turno = 1;
            if(!Quicktime){
                marcadorJugador1.setForeground(Color.GRAY);
                marcadorJugador2.setForeground(new Color(229, 203, 238));
            }
            labelJugador2.setForeground(new Color(229, 203, 238));
            if (Quicktime) {
                detenerTemporizadorJugador1();
                iniciarTemporizadorJugador2();
            }
        }
    }

    public void refresh() {
        for (int i = 0; i < posiciones.length; i++) {
            for (int j = 0; j < posiciones[0].length; j++) {
                if (posiciones[i][j] == null) {
                    botones[i][j].setIcon(null);
                } else {
                    botones[i][j].setIcon(posiciones[i][j].getImagen());
                }
            }
        }
    }



    public void preparaBotonCerrar() {
        JButton botonCerrar = new JButton();
        botonCerrar.setBounds(590, 20, 40, 40);
        botonCerrar.setForeground(Color.white);
        botonCerrar.setBackground(new Color(208, 1, 53));
        botonCerrar.setBorderPainted(false);
        botonCerrar.setFocusPainted(false);
        botonCerrar.setContentAreaFilled(false);

        String url = "icons/configuraciones/cerrar.png";
        ImageIcon imagen = new ImageIcon(url);
        botonCerrar.setIcon(imagen);

        botonCerrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        botonCerrar.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                String url = "icons/configuraciones/cerrar_selelccion.png";
                ImageIcon imagen = new ImageIcon(url);
                botonCerrar.setIcon(imagen);
            }

            public void mouseExited(MouseEvent evt) {
                String url = "icons/configuraciones/cerrar.png";
                ImageIcon imagen = new ImageIcon(url);
                botonCerrar.setIcon(imagen);
            }
        });
        panel.add(botonCerrar);
    }

    public void preparaMatrizBotones() {
        preparateElements();
        int tamañoCelda = 500 / tamañoTablero;
        for (int i = 0; i < tamañoTablero; i++) {
            for (int j = 0; j < tamañoTablero; j++) {
                botones[i][j] = new JButton();
                botones[i][j].setBounds(83 + j * tamañoCelda, 230 + i * tamañoCelda, tamañoCelda, tamañoCelda);
                botones[i][j].setBackground(Color.white);
                bottonLiseng(i, j);
                panel.add(botones[i][j]);
            }
        }
    }

    //de GUI a domain
    public void bottonLiseng(int i, int j) {
        botones[i][j].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cambioDeTurno();
                escoger = new Elegir(i, j, turno == 1 ? "blanco" : "negro");
                escoger.addWindowListener(new WindowAdapter() {
                    @Override
                    public void windowClosed(WindowEvent e) {
                        colocarFicha(i,j);
                    }
                });
                escoger.setVisible(true);
            }
        });
    }

    public void disminuir(String color, Token ficha) throws ConfiguracionIncompletaException {
        if (color.equals("blanco")) {
            informacion1.disminuir(ficha);
        } else {
            informacion2.disminuir(ficha);
        }
    }


    public void colocarFicha(int i, int j) {
        try {
            disminuir(turno == 1 ? "blanco" : "negro", escoger.getEleccion());
            if (posiciones[i][j] == null || posiciones[i][j] instanceof Casilla) {
                actualizarMatriz(control.verificarCasilla(i,j,escoger.getEleccion()));
            } else {
                throw new ConfiguracionIncompletaException(ConfiguracionIncompletaException.pocision_ocupada);
            }
        } catch (ConfiguracionIncompletaException ex) {
            Log.registrarError("Error al colocar ficha", ex);
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public void ponerEnTablero(int i, int j){
        posiciones[i][j] = escoger.getEleccion();
        botones[i][j].setIcon(posiciones[i][j].getImagen());
        control.actualizarMatriz(posiciones,turno);
        if(escoger.getEleccion() instanceof temporal || escoger.getEleccion() instanceof pesada){
            sumaFichaEspecial();
        }
    }


    public void mensajeGolden(){
        Token ficha = Golden.aleatorio(turno);
        aumentar(ficha);
    }
    public void aumentar(Token ficha){
        MensajeGolden ventana = new MensajeGolden(ficha);
        ventana.setVisible(true);
        if (ficha.getColor().equals("blanco")) {
            informacion1.aumentar(ficha);
        } else {
            informacion2.aumentar(ficha);
        }
    }

    public void ganar(int ganar){
        if(ganar==1){
            Ganar win = new Ganar(nombre1);
        }
        else {
            Ganar win = new Ganar(nombre2);
        }
        deshabilitarBotones();
        if (Quicktime){
            detenerTemporizadorJugador1();
            detenerTemporizadorJugador2();
        }
        else {
            detenerTemporizador();
        }
    }
    public void deshabilitarBotones() {
        desabilitarNombres();
        if (!juego.equals("Fichas Limitadas")) {
            informacion1.detenerTemporizador();
            informacion2.detenerTemporizador();
        }
        for (int i = 0; i < posiciones.length; i++) {
            for (int j = 0; j < posiciones.length; j++) {
                botones[i][j].setEnabled(false);
            }
        }
    }
    public void desabilitarNombres(){
        if(!Quicktime){
            marcadorJugador2.setForeground(Color.GRAY);
            marcadorJugador1.setForeground(Color.GRAY);
        }
        labelJugador1.setForeground(Color.GRAY);
        labelJugador2.setForeground(Color.GRAY);
    }
    public void guardar(){
        control.guardar(GomokuJuego.this);
    }
    public void settings(){
        settings configuracion = new settings(this);
        JButton guardar = new JButton();
        guardar.setBounds(310,190,30,30);
        guardar.setFont(new Font("Showcard Gothic", Font.PLAIN, 10));
        guardar.setBackground(new Color(253, 255, 255));

        String url = "icons/configuraciones/confi.png";
        ImageIcon imagen = new ImageIcon(url);
        guardar.setIcon(imagen);
        guardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                configuracion.setVisible(true);
            }
        });
        panel.add(guardar);
    }
    public void cargar(){
        control.cargar();
        refresh();
    }

    public void ganar(String ganar){
        Ganar win = new Ganar(ganar);
    }
    public void ganador(){
        ganar(turno);
    }

    public void actualizarMatriz(elemento[][] posiciones){
        this.posiciones=posiciones;
        refresh();
    }

}
