package presentacion.juego;
import Domain.elementos.elemento;
import controller.GomokuController;
import excepciones.ConfiguracionIncompletaException;
import Domain.elementos.fichas.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GomokuJuegoFichasLimitadas extends GomokuJuego {
    private int fichasBlancas,fichasNegras;
    private JLabel fichasRestantesBlancas,fichasRestantesNegras;
    private int fichas;

    public GomokuJuegoFichasLimitadas(String juego, String jugador, String maqui, String tablero, String nombre1, String nombre2,int fichas) {
        super(juego, jugador, maqui, tablero, nombre1, nombre2,10,11);
        this.fichas = fichas;
        tituloBlanco();
        tituloNegro();
        fichasBlancas=fichas;
        fichasNegras=fichas;
        marcadorJugador1();
        marcadorJugador2();
    }

    public int getFichas() {
        return fichas;
    }

    @Override
    public void preparateElements() {
        setUndecorated(true);
        setSize(650, 760);
        setLocationRelativeTo(null);
        titulo();
        jugador1();
        jugador2();
        preparaBotonCerrar();
        add(panel);
    }
    @Override
    public void bottonLiseng(int i, int j) {
        botones[i][j].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cambioDeTurno();
                colocarFicha(i, j);
            }
        });
    }

    @Override
    public void colocarFicha(int i, int j) {
        try {
            if (posiciones[i][j] == null) {
                posiciones[i][j] = new Token(i,j,turno == 1 ? "blanco" : "negro");
                botones[i][j].setIcon(posiciones[i][j].getImagen());
                control.actualizarMatriz(posiciones,turno);
            } else {
                throw new ConfiguracionIncompletaException(ConfiguracionIncompletaException.pocision_ocupada);
            }
        } catch (ConfiguracionIncompletaException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            posiciones[i][j] = null;
            botones[i][j].setIcon(null);
        }
    }
    @Override
    public void marcadorJugador2() {
        marcadorJugador2 = new JLabel(String.valueOf(fichasNegras));
        marcadorJugador2.setFont(new Font("Showcard Gothic", Font.BOLD, 34));
        marcadorJugador2.setForeground(new Color(229, 203, 238));
        marcadorJugador2.setBounds(460, 175, 400, 50);
        panel.add(marcadorJugador2);
    }
    @Override
    public void marcadorJugador1() {
        marcadorJugador1 = new JLabel(String.valueOf(fichasBlancas));
        marcadorJugador1.setFont(new Font("Showcard Gothic", Font.BOLD, 34));
        marcadorJugador1.setForeground(new Color(179, 245, 240));
        marcadorJugador1.setBounds(140, 175, 400, 50);
        panel.add(marcadorJugador1);
    }
    @Override
    public void cambioDeTurno() {
        if (turno == 1) {
            disminuirNegras();
            labelJugador2.setForeground(Color.GRAY);
            fichasRestantesNegras.setForeground(Color.GRAY);
            turno = 2;
            if(!Quicktime){
                marcadorJugador2.setForeground(Color.GRAY);
                marcadorJugador1.setForeground(new Color(179, 245, 240));
                fichasRestantesBlancas.setForeground(new Color(179, 245, 240));
            }
            labelJugador1.setForeground(new Color(179, 245, 240));
            if (Quicktime) {
                detenerTemporizadorJugador2();
                iniciarTemporizadorJugador1();
            }
        } else {
            disminuirBlancas();
            labelJugador1.setForeground(Color.GRAY);
            fichasRestantesBlancas.setForeground(Color.GRAY);
            turno = 1;
            if(!Quicktime){
                marcadorJugador1.setForeground(Color.GRAY);
                fichasRestantesNegras.setForeground(new Color(229, 203, 238));
                marcadorJugador2.setForeground(new Color(229, 203, 238));
            }
            labelJugador2.setForeground(new Color(229, 203, 238));
        }
    }
    public void tituloBlanco() {
        fichasRestantesBlancas = new JLabel("fichas restantes");
        fichasRestantesBlancas.setFont(new Font("Showcard Gothic", Font.BOLD, 23));
        fichasRestantesBlancas.setForeground(new Color(179, 245, 240));
        fichasRestantesBlancas.setBounds(57, 130, 400, 50);
        panel.add(fichasRestantesBlancas);
    }
    public void tituloNegro() {
        fichasRestantesNegras = new JLabel("fichas restantes");
        fichasRestantesNegras.setFont(new Font("Showcard Gothic", Font.BOLD, 23));
        fichasRestantesNegras.setForeground(new Color(229, 203, 238));
        fichasRestantesNegras.setBounds(375, 130, 400, 50);
        panel.add(fichasRestantesNegras);
    }
    @Override
    public void desabilitarNombres(){
        marcadorJugador2.setForeground(Color.GRAY);
        marcadorJugador1.setForeground(Color.GRAY);
        labelJugador1.setForeground(Color.GRAY);
        labelJugador2.setForeground(Color.GRAY);
        fichasRestantesBlancas.setForeground(Color.GRAY);
        fichasRestantesNegras.setForeground(Color.GRAY);
    }

    public void disminuirBlancas() {
        fichasBlancas--;
        if(fichasBlancas>=0){
            marcadorJugador1.setText(String.valueOf(fichasBlancas));
        }
        else{
            ganar(2);
            desabilitarNombres();
            deshabilitarBotones();
        }
    }
    public void disminuirNegras() {
        fichasNegras--;
        if(fichasNegras>=0){
            marcadorJugador2.setText(String.valueOf(fichasNegras));
        }
        else {
            ganar(1);
            desabilitarNombres();
            deshabilitarBotones();
        }

    }
    @Override
    public void preparedTablero(){
        botones = new JButton[tamañoTablero][tamañoTablero];
        posiciones = new elemento[tamañoTablero][tamañoTablero];
        control=new GomokuController(this,tamañoTablero,jugador,juego,maquina);
        imprimirMatriz();
        turno = 1;
    }


}


