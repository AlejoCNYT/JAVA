package presentacion.juego;

import excepciones.ConfiguracionIncompletaException;
import Domain.elementos.fichas.Token;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GomokuJuegoCpuFichasLimitadas extends GomokuJuegoFichasLimitadas{
    public GomokuJuegoCpuFichasLimitadas(String juego, String jugador, String maqui, String tablero, String nombre1, String nombre2,int tiempo){
        super(juego,jugador,maqui,tablero,nombre1,nombre2,tiempo);
    }
    @Override
    public void colocarFicha(int i, int j) {
        try {
            if (posiciones[i][j] == null) {
                posiciones[i][j] = new Token(i,j,"blanco");
                botones[i][j].setIcon(posiciones[i][j].getImagen());
                control.actualizarMatriz(posiciones,turno);
            } else {
                throw new ConfiguracionIncompletaException(ConfiguracionIncompletaException.pocision_ocupada);
            }
        } catch (ConfiguracionIncompletaException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            posiciones[i][j] = null;
            botones[i][j].setIcon(null);
        }
    }
    @Override
    public void bottonLiseng(int i, int j) {
        botones[i][j].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cambioDeTurno();
                colocarFicha(i,j);
            }
        });
    }
    @Override
    public void disminuir(String color, Token ficha){
    }
}
