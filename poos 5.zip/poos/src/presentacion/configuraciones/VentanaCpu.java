package presentacion.configuraciones;

import presentacion.GOMOKUGUI;
import presentacion.juego.*;
import presentacion.juego.GomokuJuegoCpu;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class VentanaCpu extends JFrame {
    private GOMOKUGUI ventanaPrincipal;
    private JTextField txtJugadorSolo;
    private JComboBox<String> comboTipoMaquina;
    private final String TEXTO_BASE_JUGADOR_SOLO = "JUGADOR SOLO";
    private final String[] tiposMaquina = {"Elige un tipo de maquina", "Agresiva", "Experta", "Miedosa", "Master"};
    private JPanel panelCentral;

    protected String tipoMaquinaSeleccionado;

    public VentanaCpu(GOMOKUGUI ventanaPrincipal) {
        this.ventanaPrincipal=ventanaPrincipal;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setUndecorated(true);
        panelCentral = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        preparedJugador1(panelCentral, gbc);
        preparedComboBox(panelCentral, gbc);
        preparedAceptarButton(ventanaPrincipal, panelCentral, gbc);

        panelCentral.setBackground(new Color(14, 19, 49));
        setLayout(new BorderLayout());
        add(panelCentral, BorderLayout.CENTER);

        getContentPane().setBackground(new Color(14, 19, 49));

        setSize(300, 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void preparedJugador1(JPanel panelCentral, GridBagConstraints gbc) {
        Font showcardFont = new Font("Showcard Gothic", Font.PLAIN, 18);
        JLabel labelJugador1 = new JLabel("Nombre del Jugador:");
        labelJugador1.setFont(showcardFont);

        txtJugadorSolo = new JTextField(TEXTO_BASE_JUGADOR_SOLO);
        txtJugadorSolo.setFont(showcardFont);
        txtJugadorSolo.setForeground(new Color(202, 105, 220));
        txtJugadorSolo.setBackground(new Color(198, 229, 227));
        txtJugadorSolo.setText(TEXTO_BASE_JUGADOR_SOLO);

        Dimension preferredSize = new Dimension(200, 30);
        txtJugadorSolo.setPreferredSize(preferredSize);
        txtJugadorSolo.setMaximumSize(preferredSize);

        txtJugadorSolo.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (txtJugadorSolo.getText().equals(TEXTO_BASE_JUGADOR_SOLO)) {
                    txtJugadorSolo.setText("");
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (txtJugadorSolo.getText().isEmpty()) {
                    txtJugadorSolo.setText(TEXTO_BASE_JUGADOR_SOLO);
                }
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 0;
        panelCentral.add(labelJugador1, gbc);

        gbc.gridy = 1;
        panelCentral.add(txtJugadorSolo, gbc);
    }


    public void preparedComboBox(JPanel panelCentral, GridBagConstraints gbc) {
        comboTipoMaquina = new JComboBox<>(tiposMaquina);
        comboTipoMaquina.setFont(new Font("Showcard Gothic", Font.PLAIN, 16));
        gbc.gridy = 2;
        panelCentral.add(comboTipoMaquina, gbc);
        comboTipoMaquina.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tipoMaquinaSeleccionado = (String) comboTipoMaquina.getSelectedItem();
            }
        });
    }

    public void preparedAceptarButton(GOMOKUGUI ventanaPrincipal, JPanel panelCentral, GridBagConstraints gbc) {
        Font showcardFont = new Font("Showcard Gothic", Font.PLAIN, 16);
        JButton btnAceptar = new JButton("Aceptar");
        btnAceptar.setFont(showcardFont);

        btnAceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombreJugadorSolo = txtJugadorSolo.getText();
                if (nombreJugadorSolo.isEmpty() || nombreJugadorSolo.equals(TEXTO_BASE_JUGADOR_SOLO)) {
                    nombreJugadorSolo = "Jugador Solo";
                }

                // Utilizar tipoMaquinaSeleccionado según sea necesario
                if (tipoMaquinaSeleccionado.equals("Elige un tipo de maquina")) {
                    tipoMaquinaSeleccionado = "Tipo no seleccionado";
                }

                dispose();
                System.out.println(tipoMaquinaSeleccionado);
                iniciar(ventanaPrincipal, nombreJugadorSolo, tipoMaquinaSeleccionado);
                ventanaPrincipal.setVisible(false);
            }
        });

        gbc.gridy = 3;
        panelCentral.add(btnAceptar, gbc);
    }

    public void iniciar(GOMOKUGUI ventanaPrincipal, String nombreJugadorSolo, String tipoMaquinaSeleccionado) {
        ventanaPrincipal.setMaquina(tipoMaquinaSeleccionado);
        if (ventanaPrincipal.getJuego().equals("Fichas Limitadas")) {
            GomokuJuegoCpuFichasLimitadas ventana = new GomokuJuegoCpuFichasLimitadas(ventanaPrincipal.getJuego(), ventanaPrincipal.getJugador(), ventanaPrincipal.getMaquina(), ventanaPrincipal.getTablero(),nombreJugadorSolo,"cpu",120);
            ventana.setVisible(true);
            setVisible(false);
        } else {
            GomokuJuegoCpu ventana = new GomokuJuegoCpu(ventanaPrincipal.getJuego(), ventanaPrincipal.getJugador(), ventanaPrincipal.getMaquina(), ventanaPrincipal.getTablero(), nombreJugadorSolo,"cpu",120);
            ventana.setVisible(true);
            ventanaPrincipal.setVisible(false);
            setVisible(false);
        }
    }

}
