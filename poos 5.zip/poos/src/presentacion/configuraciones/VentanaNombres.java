package presentacion.configuraciones;
import presentacion.GOMOKUGUI;
import presentacion.juego.GomokuJuego;
import presentacion.juego.GomokuJuegoFichasLimitadas;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

public class VentanaNombres extends JFrame {
    protected GOMOKUGUI ventanaPrincipal;
    protected JPanel  panelCentral;
    protected PanelRedondeado panel;
    protected JTextField txtJugador1,txtJugador2;
    private final String TEXTO_BASE_JUGADOR1 = "JUGADOR 1";
    private final String TEXTO_BASE_JUGADOR2 = "JUGADOR 2";
    protected boolean inicio;
    private String nombreJugador1, nombreJugador2;
    protected JLabel labelJugador1,labelJugador2,labelTiempo,labelPorcentajeCasillas;
    protected JSpinner spinnerTiempo,spinnerTiempo2,spinnerPorcentajecasillas;
    protected JButton btnIniciar;
    protected int tiempo = 60;
    protected int fichas = 100;
    protected int pocentajeFichas = 10;
    protected int pocentajeCasillas = 20;



    public VentanaNombres(GOMOKUGUI ventanaPrincipal) {
        super("Ingrese Nombres de Jugadores");
        inicio = false;
        setUndecorated(true);
        setSize(420, 260);
        this.ventanaPrincipal = ventanaPrincipal;
        setLocationRelativeTo(null);
        Font showcardFont = new Font("Showcard Gothic", Font.PLAIN, 16);
        preparedElements();
    }

    public void preparedElements() {
        preparedPanel();
        preparedTitulo();
        preparedPanelCentral();
        preparedJugador1();
        preparedJugador2();
        preparedButon();
        panelAdd();
        if(ventanaPrincipal.getJuego().equals("Quicktime")){
            preparedPorcentajeFichas();
            setSize(420, 290);
            preparedTiempo();
            porcentajeDeCasillas();
        } else if (ventanaPrincipal.getJuego().equals("Fichas Limitadas")) {
            setSize(400, 240);
            preparedFichas();}
        else{
            preparedPorcentajeFichas();
            porcentajeDeCasillas();
        }
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 45, 45));
    }

    public void preparedPanel() {
        panel = new PanelRedondeado();
        panel.setBackground(new Color(14, 19, 49));
        panel.setLayout(new BorderLayout());
    }

    public void preparedTitulo() {
        JLabel labelTitulo = new JLabel("Gomoku");
        labelTitulo.setFont(new Font("Showcard Gothic", Font.BOLD, 36));
        labelTitulo.setForeground(new Color(230, 251, 255));
        labelTitulo.setHorizontalAlignment(JLabel.CENTER);
        panel.add(labelTitulo, BorderLayout.NORTH);
    }

    public void preparedPanelCentral() {
        panelCentral = new JPanel();
        preparaBotonCerrar();
    }

    public void preparedPorcentajeFichas() {
        Font showcardFont = new Font("Showcard Gothic", Font.PLAIN, 16);
        Font showcardFont2 = new Font("Showcard Gothic", Font.PLAIN, 23);
        labelTiempo = new JLabel("porcentaje de fichas especiales:  ");
        labelTiempo.setForeground(new Color(162, 158, 152));
        labelTiempo.setFont(showcardFont);

        spinnerTiempo2 = new JSpinner(new SpinnerNumberModel(10, 1, 100, 1));
        spinnerTiempo2.setFont(showcardFont2);
        spinnerTiempo2.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                pocentajeFichas = (int) spinnerTiempo2.getValue();
            }
        });

        panelCentral.add(new JLabel(""));
        panelCentral.add(new JLabel(""));
        panelCentral.add(new JLabel(""));
        panelCentral.add(labelTiempo);
        panelCentral.add(spinnerTiempo2);
    }
    public void porcentajeDeCasillas() {
        Font showcardFont = new Font("Showcard Gothic", Font.PLAIN, 16);
        Font showcardFont2 = new Font("Showcard Gothic", Font.PLAIN, 23);

        labelPorcentajeCasillas = new JLabel("Porcentaje de casillas especiales:");
        labelPorcentajeCasillas.setForeground(new Color(162, 158, 152));
        labelPorcentajeCasillas.setFont(showcardFont);

        spinnerPorcentajecasillas = new JSpinner(new SpinnerNumberModel(10, 1, 100, 1));
        spinnerPorcentajecasillas.setFont(showcardFont2);
        spinnerPorcentajecasillas.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                pocentajeCasillas = (int) spinnerPorcentajecasillas.getValue();
            }
        });

        panelCentral.add(new JLabel(""));
        panelCentral.add(new JLabel(""));
        panelCentral.add(new JLabel(""));
        panelCentral.add(Box.createVerticalStrut(20));
        panelCentral.add(labelPorcentajeCasillas);
        panelCentral.add(spinnerPorcentajecasillas);
    }

    public void preparedTiempo() {
        Font showcardFont = new Font("Showcard Gothic", Font.PLAIN, 23);
        Font showcardFont2 = new Font("Showcard Gothic", Font.PLAIN, 23);
        labelTiempo = new JLabel("tiempo para jugar:      ");
        labelTiempo.setForeground(new Color(162, 158, 152));
        labelTiempo.setFont(showcardFont);

        spinnerTiempo = new JSpinner(new SpinnerNumberModel(60, 1, 300, 1));
        spinnerTiempo.setFont(showcardFont2);
        spinnerTiempo.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                tiempo = (int) spinnerTiempo.getValue();
            }
        });
        panelCentral.add(new JLabel(""));
        panelCentral.add(new JLabel(""));
        panelCentral.add(new JLabel(""));
        panelCentral.add(Box.createVerticalStrut(20));
        panelCentral.add(labelTiempo);
        panelCentral.add(spinnerTiempo);
    }
    public void preparedFichas() {
        Font showcardFont = new Font("Showcard Gothic", Font.PLAIN, 23);
        labelTiempo = new JLabel("¿fichas a jugar?:      ");
        labelTiempo.setForeground(new Color(162, 158, 152));
        labelTiempo.setFont(showcardFont);

        spinnerTiempo = new JSpinner(new SpinnerNumberModel(100, 1, 300, 1));
        spinnerTiempo.setFont(showcardFont);
        spinnerTiempo.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                fichas = (int) spinnerTiempo.getValue();
            }
        });
        panelCentral.add(labelTiempo);
        panelCentral.add(spinnerTiempo);
    }

    public void preparedJugador1() {
        Font showcardFont = new Font("Showcard Gothic", Font.PLAIN, 23);
        labelJugador1 = new JLabel("Nombre Jugador 1:");
        labelJugador1.setFont(showcardFont);
        labelJugador1.setForeground(new Color(162, 158, 152));

        txtJugador1 = new JTextField(TEXTO_BASE_JUGADOR1);
        txtJugador1.setFont(showcardFont);
        txtJugador1.setForeground(new Color(202, 105, 220));
        txtJugador1.setBackground(new Color(198, 229, 227));
        txtJugador1.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (txtJugador1.getText().equals(TEXTO_BASE_JUGADOR1)) {
                    txtJugador1.setText("");
                }
                if (txtJugador2.getText().isEmpty()) {
                    txtJugador2.setText(TEXTO_BASE_JUGADOR2);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (txtJugador1.getText().isEmpty()) {
                    txtJugador1.setText(TEXTO_BASE_JUGADOR1);
                }
            }
        });
    }

    public void preparedJugador2() {
        Font showcardFont = new Font("Showcard Gothic", Font.PLAIN, 23);
        labelJugador2 = new JLabel("Nombre Jugador 2:");
        labelJugador2.setFont(showcardFont);
        txtJugador2 = new JTextField(TEXTO_BASE_JUGADOR2);
        labelJugador2.setForeground(new Color(162, 158, 152));

        txtJugador2.setFont(showcardFont);
        txtJugador2.setForeground(new Color(101, 175, 245));
        txtJugador2.setBackground(new Color(229, 203, 238));
        txtJugador2.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (txtJugador2.getText().equals(TEXTO_BASE_JUGADOR2)) {
                    txtJugador2.setText("");
                }
                if (txtJugador1.getText().isEmpty()) {
                    txtJugador1.setText(TEXTO_BASE_JUGADOR1);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (txtJugador2.getText().isEmpty()) {
                    txtJugador2.setText(TEXTO_BASE_JUGADOR2);
                }
            }
        });
    }


    public void preparedButon() {
        Font showcardFont = new Font("Showcard Gothic", Font.PLAIN, 16);
        btnIniciar = new JButton("Iniciar Juego");
        btnIniciar.setFont(showcardFont);
        btnIniciar.setBackground(new Color(42, 22, 79));
        btnIniciar.setForeground(new Color(241, 227, 252));
        btnIniciar.addActionListener(e -> {
            nombreJugador1 = txtJugador1.getText();
            nombreJugador2 = txtJugador2.getText();

            if (nombreJugador1.isEmpty() || nombreJugador1.equals(TEXTO_BASE_JUGADOR1)) {
                nombreJugador1 = "Jugador 1";
            }

            if (nombreJugador2.isEmpty() || nombreJugador2.equals(TEXTO_BASE_JUGADOR2)) {
                nombreJugador2 = "Jugador 2";
            }
            iniciar();
        });

        btnIniciar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent evt) {
                btnIniciar.setBackground(new Color(126, 49, 196));
            }

            @Override
            public void mouseExited(MouseEvent evt) {
                btnIniciar.setBackground(new Color(42, 22, 79));
            }
        });
    }

    public void panelAdd() {
        panelCentral.add(labelJugador1);
        panelCentral.add(txtJugador1);
        panelCentral.add(labelJugador2);
        panelCentral.add(txtJugador2);
        panelCentral.setBackground(new Color(14, 19, 49));

        panel.add(panelCentral, BorderLayout.CENTER);
        panel.add(btnIniciar, BorderLayout.SOUTH);

        add(panel, BorderLayout.CENTER);
    }

    public void preparaBotonCerrar() {
        JButton botonCerrar = new JButton();
        botonCerrar.setBounds(360, 5, 30, 30);
        botonCerrar.setForeground(Color.white);
        botonCerrar.setBackground(new Color(208, 1, 53));
        botonCerrar.setBorderPainted(false);
        botonCerrar.setFocusPainted(false);
        botonCerrar.setContentAreaFilled(false);

        String url = "icons/configuraciones/cerrar.png";
        ImageIcon imagen = new ImageIcon(url);
        botonCerrar.setIcon(imagen);

        botonCerrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        botonCerrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                String url = "icons/configuraciones/cerrar_selelccion.png";
                ImageIcon imagen = new ImageIcon(url);
                botonCerrar.setIcon(imagen);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                String url = "icons/configuraciones/cerrar.png";
                ImageIcon imagen = new ImageIcon(url);
                botonCerrar.setIcon(imagen);
            }
        });
        panel.add(botonCerrar);
    }
    public void iniciar() {
        if(ventanaPrincipal.getJuego().equals("Fichas Limitadas")){
            GomokuJuegoFichasLimitadas ventana = new GomokuJuegoFichasLimitadas(ventanaPrincipal.getJuego(),ventanaPrincipal.getJugador(),ventanaPrincipal.getMaquina(),ventanaPrincipal.getTablero(),nombreJugador1,nombreJugador2,fichas);
            ventana.setVisible(true);
            ventanaPrincipal.setVisible(false);
            setVisible(false);
            inicio = true;
        }
        else {
            GomokuJuego ventana = new GomokuJuego(ventanaPrincipal.getJuego(),ventanaPrincipal.getJugador(),ventanaPrincipal.getMaquina(),ventanaPrincipal.getTablero(),nombreJugador1,nombreJugador2,tiempo,pocentajeFichas);
            ventana.setVisible(true);
            ventanaPrincipal.setVisible(false);
            setVisible(false);
            inicio = true;
        }
    }
    public boolean getInicio(){
        return inicio;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaNombres(null).setVisible(true));
    }
}