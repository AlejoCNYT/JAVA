package presentacion.configuraciones;

import Domain.elementos.fichas.Token;
import presentacion.juego.GomokuJuego;
import presentacion.juego.GomokuJuegoFichasLimitadas;
import presentacion.mensajes.MensajeGolden;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;

public class settings extends JFrame{
    private PanelRedondeado panel;
    private JLabel labelImagen;
    private Token ficha;
    private GomokuJuego juego;
    public settings(GomokuJuego juego){
        super();
        this.juego = juego;
        setUndecorated(true);
        setSize(500, 220);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        preparedElements();
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 47, 47));
        setVisible(true);
        guardar();
        cargar();
        reset();
        finish();
    }
    public void preparedElements() {
        panel = new PanelRedondeado();
        panel.setBackground(new Color(14, 19, 49));
        titulo();
        botonAceptar();
        add(panel);
    }
    public void guardar(){
        JButton guardar = new JButton("guardar");
        guardar.setBounds(40,90,90,40);
        guardar.setFont(new Font("Showcard Gothic", Font.PLAIN, 10));
        guardar.setBackground(new Color(179, 245, 240));
        guardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                juego.guardar();
                setVisible(false);
            }
        });
        panel.add(guardar);
    }
    public void cargar(){
        JButton cargar = new JButton("cargar");
        cargar.setBounds(160,90,80,40);
        cargar.setFont(new Font("Showcard Gothic", Font.PLAIN, 12));
        cargar.setBackground(new Color(229, 203, 238));
        cargar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                juego.cargar();
                setVisible(false);
            }
        });
        panel.add(cargar);
    }

    public void reset(){
        JButton reiniciar = new JButton("reiniciar");
        reiniciar.setBounds(260,90,100,40);
        reiniciar.setFont(new Font("Showcard Gothic", Font.PLAIN, 12));
        reiniciar.setBackground(new Color(179, 245, 240));
        reiniciar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GomokuJuego ventana = new GomokuJuego(juego.getJuego(),juego.getJugador(),juego.getMaquina(), juego.getTablero(), juego.getNombre1(), juego.getNombre2(),juego.getTiempo(),juego.getFichasEspeciales());
                if(juego.getJuego().equals("Fichas Limitadas")){
                    ventana = new GomokuJuegoFichasLimitadas(juego.getJuego(),juego.getJugador(),juego.getMaquina(), juego.getTablero(), juego.getNombre1(), juego.getNombre2(),juego.getFichas());
                }
                ventana.setVisible(true);
                juego.setVisible(false);
                setVisible(false);
            }
        });
        panel.add(reiniciar);
    }

    public static void juegoCargado(GomokuJuego juego){
        GomokuJuego ventana = new GomokuJuego(juego.getJuego(),juego.getJugador(),juego.getMaquina(), juego.getTablero(), juego.getNombre1(), juego.getNombre2(),juego.getTiempo(),juego.getFichasEspeciales());
        if(juego.getJuego().equals("Fichas Limitadas")){
            ventana = new GomokuJuegoFichasLimitadas(juego.getJuego(),juego.getJugador(),juego.getMaquina(), juego.getTablero(), juego.getNombre1(), juego.getNombre2(),juego.getFichas());
        }
        ventana.actualizarMatriz(juego.getPosiciones());
        ventana.setPuntaje(juego.getPuntosJugador1(),juego.getPuntosJugador2());
        ventana.setVisible(true);
    }
    public void finish(){
        JButton finalizar = new JButton("finish");
        finalizar.setBounds(380,90,100,40);
        finalizar.setFont(new Font("Showcard Gothic", Font.PLAIN, 12));
        finalizar.setBackground(new Color(229, 203, 238));
        finalizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        panel.add(finalizar);
    }

    public void titulo() {
        JLabel labelTitulo = new JLabel("options");
        labelTitulo.setFont(new Font("Showcard Gothic", Font.BOLD, 30));
        Color color = new Color(140, 169, 183);
        labelTitulo.setForeground(color);
        labelTitulo.setBounds(180, 20, 300, 50);

        panel.setLayout(null);
        panel.setPreferredSize(new Dimension(400, 200));
        panel.add(labelTitulo);

    }
    public void botonAceptar() {
        JButton botonAceptar = new JButton("Aceptar");
        botonAceptar.setBounds(200, 160, 100, 30);
        botonAceptar.setForeground(Color.white);
        botonAceptar.setBackground(new Color(208, 1, 53));
        botonAceptar.setBorderPainted(false);
        botonAceptar.setFocusPainted(false);


        botonAceptar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonAceptar.setBackground(new Color(238, 44, 44));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonAceptar.setBackground(new Color(208, 1, 53));
            }
        });

        botonAceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        panel.add(botonAceptar);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                settings ventana = new settings(null);
                ventana.setVisible(true);
            }
        });
    }
}
