package presentacion.configuraciones;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import excepciones.*;
import presentacion.GOMOKUGUI;

public class confi extends JFrame {
    private int ancho;
    private int alto;
    private JPanel panel;
    private JComboBox<String> modoJugador,tipoMaquina,modoJuego,tablero;

    private String jugador,maquina,juego,tamaño;

    public confi(GOMOKUGUI poo) {
        super("Configuración de Juego");
        setUndecorated(true);
        this.ancho = 500;
        this.alto = 300;
        setSize(ancho, alto);
        prepareElements();
        prepareteMenu();
        setLocationRelativeTo(null);
    }

    private void prepareElements() {
        setSize(300, 300);

        panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                String imagePath = "icons/menu2.png";
                ImageIcon imageIcon = new ImageIcon(imagePath);
                Image image = imageIcon.getImage();
                g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
            }
        };

        panel.setLayout(null);

        preparadeBoton();
        preparaBotonCerrar();

        panel.setLayout(new BorderLayout());

        add(panel);
    }

    public void preparadeBoton() {
        JButton boton = new JButton("Aceptar");
        boton.setBounds(100, 215, 100, 45);

        boton.setFont(new Font("Showcard Gothic", Font.PLAIN, 14));
        boton.setForeground(Color.white);
        Color newColor = new Color(42, 42, 122);
        boton.setBackground(newColor);

        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    verificarConfiguracionCompleta();
                    GOMOKUGUI juego = new GOMOKUGUI(confi.this);
                    juego.setVisible(true);
                    dispose();
                } catch (ConfiguracionIncompletaException ex) {
                    Log.registrarError("Error no completo configuracion", ex);
                    JOptionPane.showMessageDialog(confi.this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(boton);
    }

    private void verificarConfiguracionCompleta() throws ConfiguracionIncompletaException {
        if ("Elige un modo jugador".equals(modoJugador.getSelectedItem())
                || "Elige un modo de juego".equals(modoJuego.getSelectedItem())
                || "Elige un tamaño".equals(tablero.getSelectedItem())) {
            throw new ConfiguracionIncompletaException(ConfiguracionIncompletaException.ERROR_MESSAGE);
        }
    }


    public void preparaBotonCerrar() {
        JButton botonCerrar = new JButton(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

        botonCerrar.setBounds(260, 5, 30, 30);
        botonCerrar.setForeground(Color.white);
        botonCerrar.setBackground(new Color(208, 1, 53));
        botonCerrar.setBorderPainted(false);
        botonCerrar.setFocusPainted(false);
        botonCerrar.setContentAreaFilled(false);

        String url = "icons/configuraciones/cerrar.png";
        ImageIcon imagen = new ImageIcon(url);
        botonCerrar.setIcon(imagen);

        botonCerrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                String url = "icons/configuraciones/cerrar_selelccion.png";
                ImageIcon imagen = new ImageIcon(url);
                botonCerrar.setIcon(imagen);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                String url = "icons/configuraciones/cerrar.png";
                ImageIcon imagen = new ImageIcon(url);
                botonCerrar.setIcon(imagen);
            }
        });

        panel.add(botonCerrar);
    }

    public void prepareteMenu() {
        String[] modosJugador = {"Elige un modo jugador", "Jugador vs Jugador", "Jugador vs Máquina"};
        String[] modosJuego = {"Elige un modo de juego", "Normal", "Quicktime", "Fichas Limitadas"};
        String[] tableros = {"Elige un tamaño", "10x10", "15x15", "20x20"};

        Font boldFont = new Font("Showcard Gothic", Font.PLAIN, 16);
        Font boldFont2 = new Font("Showcard Gothic", Font.PLAIN, 12);

        initializeComboBoxes(modosJugador, modosJuego, tableros, boldFont2);
        JPanel formPanel = createFormPanel(boldFont, boldFont2);
        customizeLabels(formPanel);
        addComponentsToPanel(formPanel);

        registro();
        panel.add(formPanel, BorderLayout.CENTER);
    }

    private void initializeComboBoxes(String[] modosJugador, String[] modosJuego, String[] tableros, Font font) {
        modoJugador = new JComboBox<>(modosJugador);
        modoJugador.setFont(font);

        modoJuego = new JComboBox<>(modosJuego);
        modoJuego.setFont(font);

        tablero = new JComboBox<>(tableros);
        tablero.setFont(font);
    }

    private JPanel createFormPanel(Font boldFont, Font boldFont2) {
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 10, 15));
        formPanel.setOpaque(false);

        JLabel labelModoJugador = createLabel("Modo Jugador:", boldFont);
        JLabel labelModoJuego = createLabel("Modo de Juego:", boldFont);
        JLabel labelTamaño = createLabel("Tamaño:", boldFont);

        formPanel.add(labelModoJugador);
        formPanel.add(modoJugador);

        formPanel.add(labelModoJuego);
        formPanel.add(modoJuego);
        formPanel.add(labelTamaño);
        formPanel.add(tablero);

        Dimension comboBoxSize = new Dimension(280, 25);
        modoJugador.setPreferredSize(comboBoxSize);
        modoJuego.setPreferredSize(comboBoxSize);
        tablero.setPreferredSize(comboBoxSize);

        formPanel.setBorder(BorderFactory.createEmptyBorder(60, 10, 10, 10));

        return formPanel;
    }



    private JLabel createLabel(String text, Font font) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        return label;
    }

    private void customizeLabels(JPanel formPanel) {
        Color newColor = new Color(0, 0, 0);
        for (Component component : formPanel.getComponents()) {
            if (component instanceof JLabel) {
                ((JLabel) component).setForeground(newColor);
            }
        }
    }

    private void addComponentsToPanel(JPanel formPanel) {
        panel.add(formPanel, BorderLayout.CENTER);
    }



    public String getJugador() {
        return jugador;
    }

    public String getJuego() {
        return juego;
    }

    public String getMaquina() {
        return maquina;
    }
    public String getTablero() {
        return tamaño;
    }



    public void registro(){
        modoJugador.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jugador = (String) modoJugador.getSelectedItem();
            }
        });

        modoJuego.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                juego = (String) modoJuego.getSelectedItem();
            }
        });

        tablero.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tamaño = (String) tablero.getSelectedItem();
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new confi(null).setVisible(true);
        });
    }
}
