package presentacion;
import presentacion.configuraciones.PanelRedondeado;
import presentacion.configuraciones.VentanaCpu;
import presentacion.configuraciones.VentanaNombres;
import presentacion.configuraciones.confi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;

public class GOMOKUGUI extends JFrame {

    private PanelRedondeado panel;
    private JButton boton;
    private String jugador,maquina,juego,tablero;
    private VentanaNombres ventana;
    private boolean inicio;
    private confi configuracion;
    private VentanaCpu ventanaCpu;
    private boolean juegoConMaquina;
    private JFrame datos;

    public GOMOKUGUI(confi configuracion) {
        super("GomokuPOOs");
        inicio = false;
        setUndecorated(true);
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 47, 47));
        this.jugador = configuracion.getJugador();
        this.maquina = configuracion.getMaquina();
        this.juego = configuracion.getJuego();
        this.tablero = configuracion.getTablero();
        juegoConMaquina=false;
        prepareElements();
        prepareElementsMenu();
        setLocationRelativeTo(null);
    }
    public GOMOKUGUI() {
        super("GomokuPOOs");
        setUndecorated(true);
        this.jugador = "Jugador vs Jugador";
        this.maquina = "Miedosa";
        this.juego = "Normal";
        this.tablero = "10x10";
        prepareElements();
        prepareElementsMenu();
        setLocationRelativeTo(null);
    }

    public void setMaquina(String maquina) {
        this.maquina = maquina;
    }

    public void prepareElements() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public String getJugador() {
        return jugador;
    }

    public String getMaquina() {
        return maquina;
    }

    public String getJuego() {
        return juego;
    }

    public String getTablero() {
        return tablero;
    }

    public void prepareElementsMenu() {
        panel = new PanelRedondeado(){
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                String imagePath = "icons/menu.png";
                ImageIcon imageIcon = new ImageIcon(imagePath);
                Image image = imageIcon.getImage();
                g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
            }
        };
        panel.setLayout(null);
        panel.setPreferredSize(new Dimension(500, 700));
        preparaBotonCerrar();
        preparedButtonJugar();
        preparedButtonConfiguracion();

        setLayout(new BorderLayout());
        panel.setShape(new RoundRectangle2D.Double(0, 0, panel.getWidth(), panel.getHeight(), 47, 47));

        add(panel, BorderLayout.CENTER);

        pack();
    }

    public void preparaBotonCerrar() {
        JButton botonCerrar = new JButton();
        botonCerrar.setBounds(450, 10, 40, 40);
        botonCerrar.setForeground(Color.white);
        botonCerrar.setBackground(new Color(208, 1, 53));
        botonCerrar.setBorderPainted(false);
        botonCerrar.setFocusPainted(false);
        botonCerrar.setContentAreaFilled(false);

        String url = "./icons/configuraciones/cerrar.png";
        ImageIcon imagen = new ImageIcon(url);
        botonCerrar.setIcon(imagen);

        botonCerrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        botonCerrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                String url = "./icons/configuraciones/cerrar_selelccion.png";
                ImageIcon imagen = new ImageIcon(url);
                botonCerrar.setIcon(imagen);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                String url = "./icons/configuraciones/cerrar.png";
                ImageIcon imagen = new ImageIcon(url);
                botonCerrar.setIcon(imagen);
            }
        });
        panel.add(botonCerrar);
    }

    public void preparedButtonJugar() {
        boton = new JButton("Jugar");
        boton.setBounds(200, 580, 100, 45);

        boton.setFont(new Font("Showcard Gothic", Font.PLAIN, 14));

        boton.setForeground(Color.white);

        Color newColor = new Color(42, 42, 122);
        boton.setBackground(newColor);

        boton.setBorder(BorderFactory.createLineBorder(Color.white, 2, true));
        boton.setFocusPainted(false);

        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(jugador == "Jugador vs Máquina"){
                    juegoConMaquina=true;
                    ventanaCpu = new VentanaCpu(GOMOKUGUI.this);
                    ventanaCpu.setVisible(true);
                }
                else {
                    ventana = new VentanaNombres(GOMOKUGUI.this);
                    ventana.setVisible(true);
                }
            }
        });
        panel.add(boton);
    }


    public void preparedButtonConfiguracion() {
        boton = new JButton("Configuraciones");
        boton.setBounds(195, 630, 110, 45);

        boton.setFont(new Font("Showcard Gothic", Font.PLAIN, 10));

        boton.setForeground(Color.white);

        Color newColor = new Color(42, 42, 122);
        boton.setBackground(newColor);

        boton.setBorder(BorderFactory.createLineBorder(Color.white, 2, true));
        boton.setFocusPainted(false);

        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                configuracion = new confi(GOMOKUGUI.this);
                configuracion.setVisible(true);
            }
        });
        panel.add(boton);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new GOMOKUGUI().setVisible(true);
        });
    }
}