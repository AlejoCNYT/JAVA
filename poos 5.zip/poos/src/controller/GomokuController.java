package controller;
import Domain.*;
import Domain.elementos.fichas.Token;
import presentacion.juego.GomokuJuego;

import java.util.HashMap;
import java.util.Map;
import Domain.elementos.elemento;
import java.io.Serializable;

public class GomokuController implements Serializable{
    private GomokuJuego juego;
    private elemento[][] posiciones;

    private DomainGomoku domain;

    public GomokuController(GomokuJuego juego, int tamaño,String modosJugador,String juegos,String maquina) {
        this.juego = juego;
        if(modosJugador.equals("Jugador vs Máquina")){
            domain = new DomainGomokuCpu(this, juegos,maquina);
        }
        else{
            domain = new DomainGomoku(this);
        }
        posiciones = new Token[tamaño][tamaño];
    }
    public GomokuController() {
    }
    public elemento[][] inicializarJuego(int tamañoTablero){
        return domain.generateCasillas(tamañoTablero);
    }

    public elemento[][] verificarCasilla(int i, int j,Token Ficha){
        return domain.verificarCasilla(i,j,Ficha);
    }

    public void verificador(){
        if(domain.verificador()){
            juego.ganador();
        }
    }
    public int generateNumeroDeFichasLimitadas(){
        return domain.generateNumeroDeFichasLimitadas();
    }

    public void actualizarMatriz(elemento[][] newPosiciones,int turno){ //cuando se envia la matriz de GUI  domain.
        posiciones = newPosiciones;
        domain.actualizarMatriz(posiciones,turno);
        juego.refresh();
        verificador();
    }
    public void poner(int i,int j){
        juego.ponerEnTablero(i,j);
    }
    public Map<String, Integer>  generateTokesBlancas(int fichasEspeciales){
        return domain.generateTokensBlancas(fichasEspeciales);
    }
    public Map<String, Integer>  generateTokesNegras(int fichasEspeciales){
        return domain.generateTokensNegras(fichasEspeciales);
    }

    public void enviarMatriz(elemento[][] posiciones){ //cuando se envia la matriz de domain a GUI.
        juego.actualizarMatriz(posiciones);
    }
    public void cambioDeTurno(){
        juego.cambioDeTurno();
    }
    public void mensajeGolden(){
        juego.mensajeGolden();
    }
    public void cambiarPuntaje(HashMap<String, Integer> puntuacion){
        juego.actualizarPuntajes(puntuacion);
    }
    public void guardar(GomokuJuego estado){
        domain.guardar(estado);
    }
    public void cargar(){
        domain.cargar();
    }
    public void refresh(){
        juego.refresh();
    }
    public void cambioDeJuego(GomokuJuego sipi){
        juego = sipi;
        juego.setVisible(false);
        juego = null;
    }
}