package Domain;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import Domain.elementos.fichas.*;
import Domain.elementos.casillas.*;
import Domain.elementos.*;
import controller.*;
import presentacion.*;
import presentacion.configuraciones.*;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Map;

class DomainGomokuTest {

    @BeforeEach
    public void setUp() {
        posiciones = new Token[5][5];
    }


    //Fichas
    @Test
    public void testSetColor() {
        Token token = new Token(0, 0, "blanco");
        token.setColor("negro");
        assertEquals("negro", token.getColor());
    }

    @Test
    public void testUrlToken(){
        Token fichaBlanca = new Token(0,0,"blanco");
        Token fichaNegra = new Token(1,1,"negro");

        fichaNegra.preparedUrl();
        fichaBlanca.preparedUrl();

        assertEquals("icons/fichas/negras/fichanormalnegra.png",fichaNegra.getUrl());
        assertEquals("icons/fichas/blancas/fichas-removebg-preview.png", fichaBlanca.getUrl());
    }

    @Test
    public void testPreparedIcon(){
        Token tokenBlanco = new Token(0,0,"blanco");
        tokenBlanco.preparedIcon();

        assertNotNull(tokenBlanco.getImagen());
        assertNotNull(tokenBlanco.getUrl());
    }
    //GomokuGUI
    @Test
    public void testConstructorPredeterminado() {
        GOMOKUGUI gui = new GOMOKUGUI();

        assertEquals("Jugador vs Jugador", gui.getJugador());
        assertEquals("Miedosa", gui.getMaquina());
        assertEquals("Normal", gui.getJuego());
        assertEquals("10x10", gui.getTablero());
    }

    @Test
    public void testConstructorConConfiguracion() {
        confi configuracion = new confi(null);
        configuracion.preparadeBoton();
        configuracion.preparaBotonCerrar();
        configuracion.prepareteMenu();
        configuracion.registro();
        configuracion.setVisible(true);

        GOMOKUGUI gui = new GOMOKUGUI(configuracion);

        assertEquals(configuracion.getJugador(), gui.getJugador());
        assertEquals(configuracion.getMaquina(), gui.getMaquina());
        assertEquals(configuracion.getJuego(), gui.getJuego());
        assertEquals(configuracion.getTablero(), gui.getTablero());
    }
    public Token[][] posiciones;

    @Test
    public void testSetNullTeleport() {
        assertNotNull(posiciones);
    }
    private DomainGomoku domainGomoku;


    @BeforeEach
    public void setUp2() {
        // Assuming GomokuController is mocked or replaced as needed
        GomokuController control = new GomokuController();
        domainGomoku = new DomainGomoku(control);
    }

    @Test
    public void testAleatorioGolden() {
        int turno = 1;

        Golden golden = new Golden(2, 2);
        Token randomToken = golden.aleatorio(turno);
        assertNotNull(randomToken);
        assertTrue(randomToken instanceof Token || randomToken instanceof temporal || randomToken instanceof pesada);
        assertEquals(turno == 1 ? "blanco" : "negro", randomToken.getColor());
    }

    @Test
    public void testSetColo() {
        Token token = new Token(0, 0, "blanco");
        token.setColor("negro");
        assertEquals("negro", token.getColor());
    }

    @Test
    public void testActuarTeleport() {
        int boardSize = 5;
        elemento[][] initialBoard = new elemento[boardSize][boardSize];
        Token tokenBefore = new Token(1, 1, "blanco");
        Teleport teleport = new Teleport(2, 2);
        elemento[][] updatedBoard = teleport.actuar(initialBoard, tokenBefore);

        boolean tokenTeleported = false;
        for (elemento[] row : updatedBoard) {
            for (elemento element : row) {
                if (element == tokenBefore) {
                    tokenTeleported = true;
                }
            }
        }
        assertTrue(tokenTeleported);
    }

    @Test
    public void testCincoEnLineaHorizontal() {

        elemento[][] tablero = new elemento[][]{
                {new Token(0, 0, "blanco"), new Token(0, 1, "blanco"), new Token(0, 2, "blanco"), new Token(0, 3, "blanco"), new Token(0, 4, "blanco")},

        };


        domainGomoku.actualizarMatriz(tablero, 1);

        assertTrue(domainGomoku.cincoEnLinea());
        assertEquals("blanco", domainGomoku.getGanadorColor());
    }

    @Test
    public void testCincoEnLineaVertical() {
        elemento[][] tablero = new elemento[][]{
                {new Token(0, 0, "negro"), null, null, null, null},
                {new Token(1, 0, "negro"), null, null, null, null},
                {new Token(2, 0, "negro"), null, null, null, null},
                {new Token(3, 0, "negro"), null, null, null, null},
                {new Token(4, 0, "negro"), null, null, null, null},
        };

        domainGomoku.actualizarMatriz(tablero, 1);

        assertTrue(domainGomoku.cincoEnLinea());
        assertEquals("negro", domainGomoku.getGanadorColor());
    }

    @Test
    public void testCincoEnLineaDiagonalPrincipal() {
        elemento[][] tablero = new elemento[][]{
                {new Token(0, 0, "blanco"), null, null, null, null},
                {null, new Token(1, 1, "blanco"), null, null, null},
                {null, null, new Token(2, 2, "blanco"), null, null},
                {null, null, null, new Token(3, 3, "blanco"), null},
                {null, null, null, null, new Token(4, 4, "blanco")},
        };
        domainGomoku.actualizarMatriz(tablero, 1);
        assertTrue(domainGomoku.cincoEnLinea());
        assertEquals("blanco", domainGomoku.getGanadorColor());
    }

    @Test
    public void testCincoEnLineaDiagonalSecundaria() {
        elemento[][] tablero = new elemento[][]{
                {null, null, null, null, new Token(0, 4, "negro")},
                {null, null, null, new Token(1, 3, "negro"), null},
                {null, null, new Token(2, 2, "negro"), null, null},
                {null, new Token(3, 1, "negro"), null, null, null},
                {new Token(4, 0, "negro"), null, null, null, null},
        };

        domainGomoku.actualizarMatriz(tablero, 1);
        assertTrue(domainGomoku.cincoEnLinea());
        assertEquals("negro", domainGomoku.getGanadorColor());
    }

}